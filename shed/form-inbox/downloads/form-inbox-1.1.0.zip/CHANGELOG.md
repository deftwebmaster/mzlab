# Changelog

## 1.1.0 - 2026-11-16

Maintenance release from ManicZone Lab. Drop-in upgrade: replace the application files and keep your `config.php` and `storage-private/` folder. No data migration is needed.

### Fixed

- **A fresh install redirected to `https://forms.example.com`.** `base_url` shipped set to a placeholder, so logging in, every admin action and the generated form endpoint pointed at the wrong site until `config.php` was edited. An empty `base_url` (the new default) is detected from each request; the old placeholder is treated the same way.
- **Maintenance deleted messages you had rescued from spam, and never emptied the trash.** Retention was applied by storage folder rather than by status: anything the filter had filed as spam was removed after `spam_retention_days` even after being marked "not spam", while submissions moved to the trash were kept forever. Retention now follows each submission's current status, and purged submissions' attachments are deleted with them.
- **Only the newest 25 submissions were reachable.** The inbox fetched pages of 25 but drew no page links. It now has Newer/Older navigation.
- **Spam and trashed submissions were mixed into the inbox** and the dashboard totals. They now appear only under Spam and Trash.
- **The test script and command-line tools could be run by anyone over the web**, and the tests wrote files into live storage. `tests/` and `bin/` are now command-line only, the tests use a temporary directory, and `.htaccess` blocks both folders.
- **`storage-private/` shipped with no access rules of its own.** It now carries a deny rule (also created automatically when storage is moved), in addition to the root rewrite rule.
- Text containing invalid UTF-8 (for example a form posted in Latin-1) was stored as an empty value. It is now cleaned up and kept. Long values are cut on a character boundary so they always save.
- The copied integration HTML contained the literal text `UNIX_TIMESTAMP`, which silently disabled the "filled in too quickly" check. The snippet now includes a two-line script that sets the timestamp. A visitor clock that runs slightly fast is no longer treated as a bot.
- Schema mode with an empty or unreadable schema stored submissions with no fields. An empty schema now keeps every field, and invalid schema JSON is rejected when saving the form instead of being discarded.
- Editing a form could give it the same slug as another form.
- "Store rejected events" and "JSON responses enabled" on a form were saved but ignored. Both are now honoured.
- The "excessive uppercase" spam signal could never trigger.
- Attachments belonging to a suppressed duplicate, or uploaded alongside a file that was refused, were left on disk.
- Email subjects and sender names with accents or emoji arrived garbled; they are now encoded correctly.
- An expired admin form showed the bare text "Invalid security token." Expired forms now explain what happened and link back; an expired login form simply re-shows the login. The login page says when a lockout is in effect, and a successful login clears failed attempts.
- A failed form save sent you back to the forms list instead of the form you were editing.
- Submissions that arrive in the same second are listed newest-first.
- The Reply link encoded the address (`user%40example.com`), which some mail programs do not accept.
- The Copy buttons did nothing on plain-HTTP installs.
- CSV export raised a deprecation notice on PHP 8.4.
- The dashboard and inbox re-read storage once per submission, which became slow with large inboxes. Files are now read once per request.

### Added

- Backups can be downloaded from the Backups page.
- Diagnostics check that asks your server for a marker file in private storage and reports a failure if it can be read from the web, plus the detected base URL and installed version.
- Bulk actions and filters on the Spam and Trash screens return to the screen you were on, with a "Restore to inbox" action.
- Confirmation prompts before rotating a form token or archiving/deleting a form.
- A much larger test suite covering the fixes above.

### Changed

- Submission failures answer in the visitor's format (JSON for `fetch()` clients) instead of a bare line of text.
- Maintenance also prunes old backups and expired rate-limit and duplicate records.

## 1.0.0 - 2026-07-28

- Initial Form Inbox release.
- Added single-admin login, form endpoint management, public submission intake, JSON storage, spam controls, inbox management, CSV export, backups, diagnostics, and documentation.
