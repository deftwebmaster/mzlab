// Form Inbox admin helpers (ManicZone Lab).
(function () {
    // navigator.clipboard only exists on HTTPS; fall back so Copy still works on a
    // plain-http or intranet install instead of silently doing nothing.
    function legacyCopy(text) {
        var area = document.createElement("textarea");
        area.value = text;
        area.setAttribute("readonly", "");
        area.style.position = "fixed";
        area.style.opacity = "0";
        document.body.appendChild(area);
        area.select();
        var ok = false;
        try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
        document.body.removeChild(area);
        return ok;
    }

    document.addEventListener("click", function (event) {
        var button = event.target.closest("[data-copy]");
        if (!button) return;
        var target = document.querySelector(button.getAttribute("data-copy"));
        if (!target) return;
        var text = target.textContent;
        var label = button.getAttribute("data-label") || button.textContent;
        button.setAttribute("data-label", label);
        var done = function (ok) {
            button.textContent = ok ? "Copied" : "Press Ctrl+C";
            window.setTimeout(function () { button.textContent = label; }, 1400);
        };
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text).then(function () { done(true); }, function () { done(legacyCopy(text)); });
        } else {
            done(legacyCopy(text));
        }
    });

    // Destructive forms ask first.
    document.addEventListener("submit", function (event) {
        var message = event.target.getAttribute && event.target.getAttribute("data-confirm");
        if (message && !window.confirm(message)) event.preventDefault();
    });

    // Diagnostics: can the browser read the marker file inside private storage?
    Array.prototype.forEach.call(document.querySelectorAll("[data-probe]"), function (cell) {
        var badge = cell.parentNode.querySelector(".badge");
        var verdict = function (exposed) {
            cell.textContent = exposed
                ? "EXPOSED - private storage can be read from the web. Move it outside the web root or block it in your server configuration."
                : "Blocked - private storage cannot be read from the web.";
            if (badge) {
                badge.textContent = exposed ? "failure" : "pass";
                badge.className = "badge " + (exposed ? "failure" : "pass");
            }
        };
        fetch(cell.getAttribute("data-probe"), { cache: "no-store", credentials: "omit" })
            .then(function (response) { return response.ok ? response.text() : ""; })
            .then(function (body) { verdict(body.indexOf("form-inbox-access-probe") !== -1); })
            .catch(function () { verdict(false); });
    });
})();
