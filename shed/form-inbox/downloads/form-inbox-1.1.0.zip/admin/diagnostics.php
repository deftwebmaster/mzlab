<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
fi_send_admin_headers();
fi_require_admin();
$pageTitle = 'Diagnostics';
$checks = [
    ['PHP version', PHP_VERSION_ID >= 80200 ? 'pass' : 'failure', PHP_VERSION],
    ['JSON extension', function_exists('json_encode') ? 'pass' : 'failure', 'Required for storage.'],
    ['Session support', function_exists('session_start') ? 'pass' : 'failure', 'Required for admin login.'],
    ['Fileinfo extension', function_exists('finfo_open') ? 'pass' : 'warning', 'Recommended for attachment MIME checks.'],
    ['ZipArchive', class_exists('ZipArchive') ? 'pass' : 'warning', 'ZIP backups use this extension; JSON fallback is available.'],
    ['mail()', function_exists('mail') ? 'pass' : 'warning', 'A true return value does not guarantee inbox delivery.'],
    ['Storage writable', is_writable(fi_storage_root()) ? 'pass' : 'failure', fi_storage_root()],
    ['Attachments writable', is_writable(fi_attachment_root()) ? 'pass' : 'failure', fi_attachment_root()],
    ['Backups writable', is_writable(fi_storage_root('backups')) ? 'pass' : 'failure', fi_storage_root('backups')],
    ['Temporary writable', is_writable(fi_storage_root('temporary')) ? 'pass' : 'failure', fi_storage_root('temporary')],
    ['HTTPS detected', fi_is_https() ? 'pass' : 'warning', 'Use HTTPS for production administrator sessions.'],
    ['Password helper', is_file(fi_root_path('tools/generate-password.php')) ? 'warning' : 'pass', 'Delete the helper after setup.'],
    ['post_max_size', fi_ini_bytes((string) ini_get('post_max_size')) >= (int) fi_config('maximum_request_bytes') ? 'pass' : 'warning', (string) ini_get('post_max_size')],
    ['upload_max_filesize', fi_ini_bytes((string) ini_get('upload_max_filesize')) > 0 ? 'pass' : 'warning', (string) ini_get('upload_max_filesize')],
    ['Version', 'pass', 'Form Inbox ' . fi_version()],
    ['Base URL', rtrim((string) fi_config('base_url'), '/') === fi_base_url() ? 'pass' : 'warning',
        rtrim((string) fi_config('base_url'), '/') === fi_base_url() ? fi_base_url() : fi_base_url() . ' (detected from this request - set base_url in config.php to fix it in place)'],
];
$storageReal = realpath(fi_storage_root());
$rootReal = realpath(fi_root_path());
$probeUrl = null;
if ($storageReal && $rootReal && str_starts_with($storageReal . DIRECTORY_SEPARATOR, $rootReal . DIRECTORY_SEPARATOR)) {
    if (!is_file($storageReal . '/access-probe.txt')) {
        @file_put_contents($storageReal . '/access-probe.txt', "form-inbox-access-probe\n");
    }
    $probeUrl = fi_url(trim(str_replace('\\', '/', substr($storageReal, strlen($rootReal))), '/') . '/access-probe.txt');
}
$checks[] = $probeUrl
    ? ['Private storage blocked', 'warning', 'Checking...', $probeUrl]
    : ['Private storage blocked', 'pass', 'Storage is outside the web root.'];
ob_start();
?>
<form class="toolbar" method="post" action="actions/rebuild-index.php"><?= fi_csrf_field() ?><button class="ghost" type="submit">Rebuild submission index</button></form>
<table><thead><tr><th>Check</th><th>Status</th><th>Details</th></tr></thead><tbody>
<?php foreach ($checks as $check): [$name, $status, $details] = $check; ?>
    <tr><td><?= fi_h($name) ?></td><td><span class="badge <?= fi_h($status) ?>"><?= fi_h($status) ?></span></td><td<?= isset($check[3]) ? ' data-probe="' . fi_h($check[3]) . '"' : '' ?>><?= fi_h($details) ?></td></tr>
<?php endforeach; ?>
</tbody></table>
<section class="panel" style="margin-top:16px">
    <h2>Rejected Attempts</h2>
    <?php $events = array_reverse(fi_json_read('data/rejected-events.json', [])); ?>
    <?php if ($events === []): ?><p class="muted">No rejected attempts recorded.</p><?php else: ?>
        <table><thead><tr><th>Time</th><th>Reason</th><th>Form</th></tr></thead><tbody>
        <?php foreach (array_slice($events, 0, 50) as $event): ?><tr><td><?= fi_h($event['created_at'] ?? '') ?></td><td><?= fi_h($event['reason'] ?? '') ?></td><td><?= fi_h($event['form_id'] ?? $event['slug'] ?? '') ?></td></tr><?php endforeach; ?>
        </tbody></table>
    <?php endif; ?>
</section>
<?php
$content = ob_get_clean();
require fi_root_path('templates/admin-layout.php');
