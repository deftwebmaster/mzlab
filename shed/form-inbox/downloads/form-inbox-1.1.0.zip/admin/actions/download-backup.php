<?php
declare(strict_types=1);
require_once __DIR__ . '/../../includes/bootstrap.php';
fi_require_admin();
fi_require_csrf();
// Backups live in private storage, so this is the only way to get one off the server
// without FTP. Only a plain filename inside the backups folder is accepted.
$name = basename((string) ($_GET['name'] ?? ''));
$path = fi_storage_root('backups/' . $name);
$root = realpath(fi_storage_root('backups'));
$real = realpath($path);
if ($name === '' || !$root || !$real || !str_starts_with($real, $root . DIRECTORY_SEPARATOR) || !is_file($real)) {
    http_response_code(404);
    exit('Backup not found.');
}
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}
while (ob_get_level() > 0) {
    ob_end_clean();
}
header('Content-Type: ' . (str_ends_with($name, '.zip') ? 'application/zip' : 'application/json'));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');
header('Content-Length: ' . filesize($real));
header('Content-Disposition: attachment; filename="' . preg_replace('/[^\w.\-]+/', '_', $name) . '"');
readfile($real);
