<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
fi_send_admin_headers();
fi_require_admin();
$view = basename((string) ($_SERVER['SCRIPT_NAME'] ?? 'inbox.php'));
$view = in_array($view, ['spam.php', 'trash.php'], true) ? $view : 'inbox.php';
$pageTitle = ['spam.php' => 'Spam', 'trash.php' => 'Trash'][$view] ?? 'Inbox';
$filters = [
    'q' => (string) ($_GET['q'] ?? ''),
    'form_id' => (string) ($_GET['form_id'] ?? ''),
    'status' => (string) ($_GET['status'] ?? ''),
    'failed_notifications' => !empty($_GET['failed_notifications']),
    'attachments' => !empty($_GET['attachments']),
];
$page = max(1, (int) ($_GET['page'] ?? 1));
$list = fi_submission_list($filters, $page, 25);
$forms = fi_forms_all();
ob_start();
?>
<form class="toolbar" method="get" action="<?= fi_h($view) ?>">
    <label>Search <input name="q" value="<?= fi_h($filters['q']) ?>" maxlength="120"></label>
    <label>Form <select name="form_id"><option value="">All forms</option><?php foreach ($forms as $form): ?><option value="<?= fi_h($form['id']) ?>" <?= $filters['form_id'] === $form['id'] ? 'selected' : '' ?>><?= fi_h($form['name']) ?></option><?php endforeach; ?></select></label>
    <label>Status <select name="status"><option value="">Any status</option><?php foreach (['new','read','replied','archived','spam','deleted'] as $status): ?><option value="<?= $status ?>" <?= $filters['status'] === $status ? 'selected' : '' ?>><?= ucfirst($status) ?></option><?php endforeach; ?></select></label>
    <button type="submit">Filter</button>
</form>
<form method="post" action="actions/bulk-action.php">
    <?= fi_csrf_field() ?>
    <input type="hidden" name="return" value="<?= fi_h($view) ?>">
    <div class="toolbar">
        <select name="action" aria-label="Bulk action">
            <option value="read">Mark read</option>
            <option value="new">Mark unread</option>
            <option value="archived">Archive</option>
            <option value="spam">Mark spam</option>
            <option value="deleted">Move to trash</option>
            <?php if ($view !== 'inbox.php'): ?><option value="read">Restore to inbox</option><?php endif; ?>
        </select>
        <button class="ghost" type="submit">Apply</button>
        <a class="button ghost" href="exports.php">Export</a>
    </div>
    <?php if ($list['items'] === []): ?>
        <div class="panel"><p class="muted">No matching submissions.</p></div>
    <?php else: ?>
        <table>
            <caption><?= (int) $list['total'] ?> submission(s)</caption>
            <thead><tr><th><span class="muted">Select</span></th><th>Status</th><th>Form</th><th>Sender</th><th>Preview</th><th>Attachments</th><th>Notification</th><th>Received</th></tr></thead>
            <tbody>
            <?php foreach ($list['items'] as $row): $submission = $row['submission']; $form = $list['forms'][(string) $submission['form_id']] ?? []; ?>
                <tr>
                    <td><input type="checkbox" name="ids[]" value="<?= fi_h($submission['id']) ?>" aria-label="Select <?= fi_h($submission['id']) ?>"></td>
                    <td><span class="badge <?= fi_h($submission['status']) ?>"><?= fi_h($submission['status']) ?></span></td>
                    <td><?= fi_h($form['name'] ?? $submission['form_id']) ?></td>
                    <td><a href="submission.php?id=<?= fi_h(rawurlencode($submission['id'])) ?>"><?= fi_h(fi_submission_sender($submission)) ?></a><br><small><?= fi_h(fi_submission_email($submission) ?? '') ?></small></td>
                    <td><?= fi_h(fi_submission_preview($submission)) ?></td>
                    <td><?= count((array) ($submission['attachments'] ?? [])) ?></td>
                    <td><span class="badge <?= fi_h($submission['notification_status'] ?? '') ?>"><?= fi_h($submission['notification_status'] ?? 'n/a') ?></span></td>
                    <td><?= fi_h(fi_local_time($submission['received_at'])) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php
        // 1.0.0 fetched 25 rows per page but drew no page links, so anything older than
        // the newest 25 submissions could only be reached by searching.
        $pages = (int) ceil($list['total'] / max(1, $list['per_page']));
        if ($pages > 1):
            $query = array_filter([
                'q' => (string) $filters['q'],
                'form_id' => (string) $filters['form_id'],
                'status' => $view === 'inbox.php' ? (string) $filters['status'] : '',
            ], static fn(string $value): bool => $value !== '');
            $link = static fn(int $n): string => $view . '?' . http_build_query($query + ['page' => $n]);
        ?>
        <nav class="toolbar pagination" aria-label="Pages">
            <?php if ($page > 1): ?><a class="button ghost" href="<?= fi_h($link($page - 1)) ?>">&larr; Newer</a><?php endif; ?>
            <span class="muted">Page <?= (int) $page ?> of <?= $pages ?></span>
            <?php if ($page < $pages): ?><a class="button ghost" href="<?= fi_h($link($page + 1)) ?>">Older &rarr;</a><?php endif; ?>
        </nav>
        <?php endif; ?>
    <?php endif; ?>
</form>
<?php
$content = ob_get_clean();
require fi_root_path('templates/admin-layout.php');
