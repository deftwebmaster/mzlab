# Form Inbox

Form Inbox is a free self-hosted PHP form backend for static websites, from [ManicZone Lab](https://lab.maniczone.com/shed/form-inbox/). Create a private form endpoint, point any ordinary HTML form at it, and read submissions in a browser-based inbox.

It uses PHP 8.2+, JSON flat files, local assets, PHP sessions, and the host's configured `mail()` transport. It does not use SQL, Composer, Node.js, a frontend framework, or a third-party form service.

## Features

- Single administrator login with secure sessions, CSRF tokens, and login rate limiting.
- Multiple registered form endpoints at `/submit/{slug}` plus `submit.php?form={slug}` fallback.
- Public form tokens, allowed-origin checks, CORS preflight support, honeypot checks, timing checks, duplicate suppression, and flat-file rate limiting.
- Flexible fields by default, optional schema validation for required fields and typed values.
- Segmented JSON submission storage with locked atomic writes and a rebuildable index.
- Inbox search, filtering, status changes, spam/trash views, submission detail pages, CSV export, backups, diagnostics, and optional private attachments.
- Email notifications through PHP `mail()` with Reply-To safely set from a configured visitor email field.

## Requirements

- PHP 8.2 or newer
- Apache with `mod_rewrite` recommended
- Writable private storage directory
- PHP extensions: JSON and sessions required, Fileinfo recommended, ZipArchive recommended

## Installation

1. Upload the files to a PHP-capable host.
2. Move `storage-private/` outside the public web root when your host allows it.
3. Copy `config.example.php` to `config.php`, or edit the included `config.php`.
4. Set `timezone`, `storage_path`, `attachment_path`, sender email, `visitor_hash_salt`, and the administrator password hash. `base_url` may be left empty; it is then detected from each request.
5. Open `/tools/generate-password.php`, generate a password hash, paste it into `config.php`, then delete the helper.
6. Ensure `data/`, `attachments/`, `backups/`, `logs/`, `locks/`, and `temporary/` are writable.
7. Open `/admin/login.php`, log in, create a form, and copy the generated integration HTML.
8. Open **Diagnostics** and confirm every check passes, including "Private storage blocked".

## Static HTML Example

```html
<form action="https://forms.example.com/submit/contact" method="post">
    <input type="hidden" name="_form_token" value="PUBLIC_FORM_TOKEN">
    <input type="hidden" name="_form_loaded_at" value="">

    <label>Name <input type="text" name="name" required></label>
    <label>Email <input type="email" name="email" required></label>
    <label>Message <textarea name="message" required></textarea></label>

    <div style="position:absolute; left:-10000px; width:1px; height:1px; overflow:hidden;" aria-hidden="true">
        <label>Website <input type="text" name="_website" tabindex="-1" autocomplete="off"></label>
    </div>

    <button type="submit">Send</button>
</form>
<script>
// Records when the form was shown, for the "filled in too quickly" spam check.
document.querySelectorAll('input[name="_form_loaded_at"]').forEach(function (field) {
    field.value = Math.floor(Date.now() / 1000);
});
</script>
```

The script is optional: without it the timing check is simply skipped. Without URL rewriting, post to `submit.php?form=contact` instead of `/submit/contact`.

For JavaScript `fetch()` submissions from another domain, add the exact page origin, such as `https://example.com`, to the form's allowed origins. Form Inbox never returns wildcard CORS headers for configured browser integrations.

## Nginx Example

```nginx
location /submit/ {
    rewrite ^/submit/([a-zA-Z0-9-]+)/?$ /submit.php?form=$1 last;
}

location ~ ^/(storage-private|includes|templates|bin|tests)/ {
    deny all;
}

location ~ /(config\.php|config\.example\.php|VERSION)$ {
    deny all;
}
```

Nginx ignores `.htaccess` files, so these `deny` rules are what protect submissions there. The Diagnostics page tests this for you.

## Email Notes

Form Inbox uses PHP `mail()`. A successful `mail()` call means the host accepted the message for delivery; it does not guarantee the email reached the final inbox. Form Inbox stores valid submissions before notification attempts, so mail failures are visible in the admin dashboard and can be retried.

Use a sender address owned by the PHP host domain. Visitor email addresses are used only as `Reply-To` when configured.

## Privacy

By default Form Inbox does not store raw visitor IP addresses, does not set tracking cookies, strips referrer query strings, stores only broad device categories, and keeps visitor hashes only for abuse prevention.

## Maintenance

Run manually or from cron:

```sh
php bin/maintenance.php
php bin/rebuild-index.php
```

The app still works without cron.

Maintenance permanently removes submissions that have been in the **Trash** longer than `trash_retention_days`, and submissions still marked **Spam** after `spam_retention_days`, together with their attachments. A message you move back out of Spam or Trash is never removed. It also prunes old backups.

## Backups

**Backups** creates a ZIP of private storage (forms, submissions, attachments) and lets you download it. To restore, unpack a backup over your private storage folder, then use **Diagnostics → Rebuild submission index**.

## Upgrading

Back up the project and private storage, replace the application files, and keep your `config.php` and `storage-private/` folder. Then open Diagnostics. See `CHANGELOG.md` for what changed in each release.

Upgrading from 1.0.0: no data changes are needed. Re-copy the integration HTML for any form whose page still contains `value="UNIX_TIMESTAMP"`. If you run `bin/maintenance.php` from cron, note that it now empties the trash, which 1.0.0 never did.

## Troubleshooting

- Login redirects to the wrong site, or pages load unstyled: clear `base_url` in `config.php` (or set it to the folder's real address).
- Login fails: check `admin_password_hash`. Five wrong passwords pause logins for 10 minutes; successful logins never count.
- Submissions are rejected with "could not be verified": the hidden `_form_token` on your page does not match the form's current public token.
- Submissions from your site are refused: add the page's exact origin (for example `https://example.com`) to the form's allowed origins.
- Visitors see "Too many submissions": raise the form's rate limit; every attempt counts, including ones that failed validation.
- No notification email: see Email Notes above, and the Notification line on the submission.

## Tests

```sh
php tests/run.php
```

The suite runs from the command line only and uses a temporary directory, so it never touches your real data.

## Scalability

Form Inbox is designed for small and medium static sites with hundreds or low thousands of submissions. Very high-volume forms should use a database-backed or dedicated form-processing service.

## Credits

Form Inbox is made and maintained by ManicZone Lab as part of the Script Shed: https://lab.maniczone.com/shed/

## License

MIT. Copyright (c) 2026 ManicZone Lab.
