<?php

declare(strict_types=1);

function fi_config(?string $key = null, mixed $default = null): mixed
{
    static $config = null;

    if ($config === null) {
        $example = require fi_root_path('config.example.php');
        $localPath = fi_root_path('config.php');
        $local = is_file($localPath) ? require $localPath : [];
        if (!is_array($local)) {
            $local = [];
        }
        $config = array_replace($example, $local);
        // The test suite points storage at a throwaway directory so it never touches live data.
        if (defined('FI_TEST_STORAGE')) {
            $config['storage_path'] = FI_TEST_STORAGE;
            $config['attachment_path'] = FI_TEST_STORAGE . '/attachments';
        }
        if (@timezone_open((string) ($config['timezone'] ?? '')) === false) {
            $config['timezone'] = 'UTC';
        }
        fi_validate_config($config);
    }

    if ($key === null) {
        return $config;
    }

    return array_key_exists($key, $config) ? $config[$key] : $default;
}

function fi_validate_config(array $config): void
{
    $required = ['app_name', 'timezone', 'storage_path', 'attachment_path'];
    foreach ($required as $key) {
        if (!isset($config[$key]) || trim((string) $config[$key]) === '') {
            throw new RuntimeException('Missing configuration value: ' . $key);
        }
    }
    // base_url may be left empty: it is then detected from each request.
    $base = trim((string) ($config['base_url'] ?? ''));
    if ($base !== '' && !filter_var($base, FILTER_VALIDATE_URL)) {
        throw new RuntimeException('The configured base_url is not a valid URL.');
    }
    if ((int) PHP_VERSION_ID < 80200) {
        throw new RuntimeException('Form Inbox requires PHP 8.2 or newer.');
    }
}
