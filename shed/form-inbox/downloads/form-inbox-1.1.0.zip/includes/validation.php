<?php

declare(strict_types=1);

function fi_normalize_submission_fields(array $input, array $form): array
{
    $fields = [];
    $errors = [];
    $maxFields = (int) ($form['maximum_fields'] ?? fi_config('maximum_fields'));
    $count = 0;

    foreach ($input as $name => $value) {
        $name = fi_scrub_utf8((string) $name);
        if (str_starts_with($name, '_')) {
            continue;
        }
        if ($name === '' || strlen($name) > (int) fi_config('maximum_field_name_length') || preg_match('/[\\x00-\\x1F\\x7F]/', $name)) {
            $errors[$name ?: 'field'] = 'This field name is not allowed.';
            continue;
        }
        $count++;
        if ($count > $maxFields) {
            $errors['_form'] = 'Too many fields were submitted.';
            break;
        }
        $fields[$name] = fi_normalize_field_value($value, 0);
        if (strlen(json_encode($fields[$name], JSON_UNESCAPED_UNICODE) ?: '') > (int) fi_config('maximum_field_bytes')) {
            $errors[$name] = 'This value is too long.';
        }
    }

    // Schema mode with no schema would discard every field and store empty submissions,
    // so an empty schema behaves like flexible mode.
    $schema = (array) ($form['field_schema'] ?? []);
    if (($form['field_mode'] ?? 'flexible') === 'schema' && $schema !== []) {
        [$fields, $schemaErrors] = fi_validate_schema_fields($fields, $schema);
        $errors = array_replace($errors, $schemaErrors);
    }

    return [$fields, $errors];
}

function fi_normalize_field_value(mixed $value, int $depth): mixed
{
    if ($depth > (int) fi_config('maximum_array_depth')) {
        return '';
    }
    if (is_array($value)) {
        $normalized = [];
        foreach ($value as $item) {
            $normalized[] = fi_normalize_field_value($item, $depth + 1);
        }
        return $normalized;
    }
    // Scrub invalid UTF-8 first: the /u pattern below returns null on bad bytes, which
    // used to turn the whole value into an empty string and lose the visitor's text.
    $value = fi_scrub_utf8(trim((string) $value));
    $value = preg_replace('/[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]/u', '', $value) ?? $value;
    return fi_truncate_utf8($value, (int) fi_config('maximum_field_bytes'));
}

function fi_validate_schema_fields(array $fields, array $schema): array
{
    $errors = [];
    $filtered = [];
    foreach ($schema as $name => $rule) {
        $value = $fields[$name] ?? '';
        $required = !empty($rule['required']);
        if ($required && ($value === '' || $value === [])) {
            $errors[(string) $name] = 'This field is required.';
            continue;
        }
        if ($value === '' || $value === []) {
            $filtered[(string) $name] = $value;
            continue;
        }
        $type = strtolower((string) ($rule['type'] ?? 'text'));
        $max = (int) ($rule['maximum_length'] ?? fi_config('maximum_field_bytes'));
        $stringValue = is_array($value) ? implode(', ', array_map('strval', $value)) : (string) $value;
        if (strlen($stringValue) > $max) {
            $errors[(string) $name] = 'This field is too long.';
        }
        if ($type === 'email' && fi_safe_mailbox($stringValue) === null) {
            $errors[(string) $name] = 'Enter a valid email address.';
        }
        if ($type === 'url' && !filter_var($stringValue, FILTER_VALIDATE_URL)) {
            $errors[(string) $name] = 'Enter a valid URL.';
        }
        if ($type === 'integer' && filter_var($stringValue, FILTER_VALIDATE_INT) === false) {
            $errors[(string) $name] = 'Enter a whole number.';
        }
        if ($type === 'number' && !is_numeric($stringValue)) {
            $errors[(string) $name] = 'Enter a number.';
        }
        if ($type === 'consent checkbox' && !in_array(strtolower($stringValue), ['1', 'yes', 'on', 'true'], true)) {
            $errors[(string) $name] = 'Consent is required.';
        }
        $filtered[(string) $name] = $value;
    }
    return [$filtered, $errors];
}

function fi_validate_origin(array $form): array
{
    $mode = (string) ($form['origin_validation_mode'] ?? 'compatible');
    if ($mode === 'disabled') {
        return [true, null];
    }
    $allowed = array_values(array_filter(array_map('fi_normalize_origin', (array) ($form['allowed_origins'] ?? []))));
    if ($allowed === []) {
        return [$mode === 'compatible', 'No allowed origins are configured.'];
    }
    $origin = fi_normalize_origin($_SERVER['HTTP_ORIGIN'] ?? null);
    if ($origin !== null && in_array($origin, $allowed, true)) {
        return [true, null];
    }
    if ($mode === 'strict') {
        return [false, 'The request origin is not allowed.'];
    }
    $ref = fi_normalize_origin($_SERVER['HTTP_REFERER'] ?? null);
    if ($ref !== null && in_array($ref, $allowed, true)) {
        return [true, null];
    }
    if ($origin === null && $ref === null) {
        return [true, 'Origin and referrer headers were absent.'];
    }
    return [false, 'The request origin is not allowed.'];
}

function fi_validate_redirect_url(string $url, array $form): ?string
{
    $url = trim($url);
    if ($url === '') {
        return null;
    }
    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        return null;
    }
    $origin = fi_normalize_origin($url);
    $allowed = array_values(array_filter(array_map('fi_normalize_origin', (array) ($form['allowed_origins'] ?? []))));
    return $origin !== null && in_array($origin, $allowed, true) ? $url : null;
}
