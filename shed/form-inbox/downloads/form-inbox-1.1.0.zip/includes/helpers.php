<?php

declare(strict_types=1);

function fi_root_path(string $path = ''): string
{
    $root = dirname(__DIR__);
    return $path === '' ? $root : $root . '/' . ltrim($path, '/');
}

function fi_h(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function fi_now(): string
{
    return gmdate('Y-m-d\TH:i:s\Z');
}

function fi_local_time(string $iso): string
{
    $timestamp = strtotime($iso);
    return $timestamp ? date('M j, Y g:i A', $timestamp) : $iso;
}

function fi_random_id(string $prefix): string
{
    return $prefix . '_' . strtoupper(bin2hex(random_bytes(8)));
}

function fi_public_token(): string
{
    return 'fi_pub_' . rtrim(strtr(base64_encode(random_bytes(18)), '+/', 'AZ'), '=');
}

function fi_slugify(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9]+/', '-', $value) ?? '';
    $value = trim($value, '-');
    return $value !== '' ? substr($value, 0, 80) : 'form-' . strtolower(bin2hex(random_bytes(3)));
}

function fi_base_url(): string
{
    static $base = null;
    if ($base === null) {
        $base = rtrim((string) fi_config('base_url'), '/');
        // config.php ships pointing at https://forms.example.com, so a fresh upload sent
        // every admin redirect and generated endpoint to that placeholder until the file
        // was edited. An empty value, or the placeholder on any other host, is now
        // worked out from the request instead.
        $host = (string) ($_SERVER['HTTP_HOST'] ?? '');
        $placeholder = $base === 'https://forms.example.com' && $host !== '' && $host !== 'forms.example.com';
        if (($base === '' || $placeholder) && PHP_SAPI !== 'cli' && $host !== '') {
            $base = (fi_is_https() || (int) ($_SERVER['SERVER_PORT'] ?? 80) === 443 ? 'https://' : 'http://')
                . $host . fi_install_path((string) ($_SERVER['SCRIPT_NAME'] ?? ''));
        }
    }
    return $base;
}

/** URL path of the install root, worked out from the running script's own path. */
function fi_install_path(string $scriptName): string
{
    $dir = str_replace('\\', '/', dirname($scriptName));
    $dir = preg_replace('#/(admin/actions|admin|tools|bin|tests)$#', '', $dir) ?? '';
    return rtrim($dir, '/');
}

function fi_version(): string
{
    return trim((string) @file_get_contents(fi_root_path('VERSION'))) ?: '1.1.0';
}

/** Make any byte string safe to store as JSON: invalid UTF-8 sequences become "?". */
function fi_scrub_utf8(string $value): string
{
    if ($value === '' || preg_match('//u', $value) === 1) {
        return $value;
    }
    if (function_exists('mb_scrub')) {
        return mb_scrub($value, 'UTF-8');
    }
    $clean = @iconv('UTF-8', 'UTF-8//IGNORE', $value);
    return is_string($clean) ? $clean : (preg_replace('/[^\x09\x0A\x0D\x20-\x7E]/', '?', $value) ?? '');
}

/** Cut to at most $bytes bytes without splitting a multi-byte character. */
function fi_truncate_utf8(string $value, int $bytes): string
{
    if ($bytes <= 0 || strlen($value) <= $bytes) {
        return $value;
    }
    $cut = substr($value, 0, $bytes);
    // Back off byte by byte (at most three) if the cut landed inside a character.
    while ($cut !== '' && preg_match('//u', $cut) !== 1) {
        $cut = substr($cut, 0, -1);
    }
    return $cut;
}

function fi_url(string $path): string
{
    return fi_base_url() . '/' . ltrim($path, '/');
}

function fi_admin_url(string $path = 'index.php'): string
{
    return fi_url('admin/' . ltrim($path, '/'));
}

function fi_redirect(string $url, int $status = 302): never
{
    header('Location: ' . $url, true, $status);
    exit;
}

function fi_request_method(): string
{
    return strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
}

function fi_request_wants_json(): bool
{
    $accept = strtolower($_SERVER['HTTP_ACCEPT'] ?? '');
    $format = strtolower((string) ($_POST['_response_format'] ?? $_GET['_response_format'] ?? ''));
    return str_contains($accept, 'application/json') || $format === 'json';
}

function fi_json_response(array $data, int $status = 200, array $headers = []): never
{
    http_response_code($status);
    foreach ($headers as $name => $value) {
        header($name . ': ' . $value);
    }
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function fi_normalize_origin(?string $origin): ?string
{
    if ($origin === null || trim($origin) === '') {
        return null;
    }
    $parts = parse_url(trim($origin));
    if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
        return null;
    }
    $scheme = strtolower($parts['scheme']);
    if ($scheme !== 'http' && $scheme !== 'https') {
        return null;
    }
    $host = strtolower($parts['host']);
    $port = isset($parts['port']) ? ':' . (int) $parts['port'] : '';
    return $scheme . '://' . $host . $port;
}

function fi_strip_referrer(?string $referrer): ?string
{
    if (!$referrer || !fi_config('track_referrer')) {
        return null;
    }
    $parts = parse_url($referrer);
    if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
        return null;
    }
    $url = strtolower((string) $parts['scheme']) . '://' . strtolower((string) $parts['host']);
    if (!empty($parts['path'])) {
        $url .= $parts['path'];
    }
    return substr($url, 0, 500);
}

function fi_device_category(?string $userAgent): string
{
    if (!fi_config('track_device_category') || !$userAgent) {
        return 'unknown';
    }
    $ua = strtolower($userAgent);
    if (str_contains($ua, 'bot') || str_contains($ua, 'crawl') || str_contains($ua, 'spider')) {
        return 'bot';
    }
    if (str_contains($ua, 'mobile') || str_contains($ua, 'iphone') || str_contains($ua, 'android')) {
        return 'mobile';
    }
    if (str_contains($ua, 'tablet') || str_contains($ua, 'ipad')) {
        return 'tablet';
    }
    return 'desktop';
}

function fi_client_hash(): string
{
    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    $prefix = str_contains($ip, ':') ? substr($ip, 0, 20) : preg_replace('/\.\d+$/', '.0', $ip);
    return hash('sha256', (string) $prefix . '|' . (string) fi_config('visitor_hash_salt'));
}

function fi_admin_flash(?string $message = null, string $type = 'info'): ?array
{
    if ($message !== null) {
        $_SESSION['flash'] = ['message' => $message, 'type' => $type];
        return null;
    }
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return is_array($flash) ? $flash : null;
}

function fi_safe_mailbox(string $email): ?string
{
    $email = trim(str_replace(["\r", "\n"], '', $email));
    return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : null;
}

function fi_ini_bytes(string $value): int
{
    $value = trim($value);
    if ($value === '') {
        return 0;
    }
    $unit = strtolower(substr($value, -1));
    $number = (float) $value;
    return (int) match ($unit) {
        'g' => $number * 1024 * 1024 * 1024,
        'm' => $number * 1024 * 1024,
        'k' => $number * 1024,
        default => $number,
    };
}
