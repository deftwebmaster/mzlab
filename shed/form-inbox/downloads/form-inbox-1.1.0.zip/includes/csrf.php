<?php

declare(strict_types=1);

function fi_csrf_token(): string
{
    fi_boot_session();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return (string) $_SESSION['csrf_token'];
}

function fi_csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . fi_h(fi_csrf_token()) . '">';
}

function fi_require_csrf(): void
{
    fi_boot_session();
    $provided = (string) ($_POST['_csrf'] ?? $_GET['_csrf'] ?? '');
    $actual = (string) ($_SESSION['csrf_token'] ?? '');
    if ($actual === '' || $provided === '' || !hash_equals($actual, $provided)) {
        $limit = fi_ini_bytes((string) ini_get('post_max_size'));
        $tooLarge = $_POST === [] && $limit > 0 && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > $limit;
        http_response_code($tooLarge ? 413 : 403);
        fi_send_admin_headers();
        $message = $tooLarge
            ? 'That upload is larger than this server accepts in one request (post_max_size is ' . ini_get('post_max_size') . '). Nothing was changed.'
            : 'That form had expired, so nothing was changed. Go back, reload the page and try again.';
        echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Form expired</title>'
            . '<link rel="stylesheet" href="' . fi_h(fi_url('assets/css/admin.css')) . '"></head><body><main class="public-card" style="margin:10vh auto;max-width:480px">'
            . '<h1>Nothing was changed</h1><p>' . fi_h($message) . '</p><p><a class="button" href="' . fi_h(fi_admin_url('index.php')) . '">Back to the dashboard</a></p></main></body></html>';
        exit;
    }
}

/** Same check as fi_require_csrf(), but returns the verdict instead of ending the request. */
function fi_csrf_valid(): bool
{
    fi_boot_session();
    $provided = (string) ($_POST['_csrf'] ?? '');
    $actual = (string) ($_SESSION['csrf_token'] ?? '');
    return $actual !== '' && $provided !== '' && hash_equals($actual, $provided);
}
