<?php

declare(strict_types=1);

function fi_storage_root(string $path = ''): string
{
    $root = rtrim((string) fi_config('storage_path'), '/');
    return $path === '' ? $root : $root . '/' . ltrim($path, '/');
}

function fi_attachment_root(string $path = ''): string
{
    $root = rtrim((string) fi_config('attachment_path'), '/');
    return $path === '' ? $root : $root . '/' . ltrim($path, '/');
}

function fi_storage_bootstrap(): void
{
    $dirs = [
        'data/submissions',
        'data/spam',
        'data/trash',
        'data/indexes',
        'attachments',
        'backups',
        'logs',
        'locks',
        'temporary',
    ];

    foreach ($dirs as $dir) {
        $path = $dir === 'attachments' ? fi_attachment_root() : fi_storage_root($dir);
        if (!is_dir($path)) {
            mkdir($path, 0775, true);
        }
    }

    // Keep the web server out of private data even if the root rewrite rules are not
    // applied. 1.0.0 shipped this folder with no guard files at all.
    $guard = fi_storage_root('.htaccess');
    if (!is_file($guard)) {
        @file_put_contents($guard, "Require all denied\n<IfModule !mod_authz_core.c>\n    Deny from all\n</IfModule>\n");
    }
    $index = fi_storage_root('index.php');
    if (!is_file($index)) {
        @file_put_contents($index, "<?php\nhttp_response_code(404);\n");
    }

    fi_json_ensure('data/forms.json', []);
    fi_json_ensure('data/rate-limits.json', []);
    fi_json_ensure('data/rejected-events.json', []);
    fi_json_ensure('data/indexes/submission-index.json', []);
}

function fi_json_ensure(string $relativePath, mixed $default): void
{
    $path = fi_storage_root($relativePath);
    if (!is_file($path)) {
        fi_json_write_locked($relativePath, $default);
    }
}

function fi_lock_path(string $relativePath): string
{
    return fi_storage_root('locks/' . preg_replace('/[^a-zA-Z0-9_.-]+/', '_', $relativePath) . '.lock');
}

/**
 * Per-request cache of decoded files for read-heavy screens. The dashboard and inbox
 * look up every submission through the index; without this each lookup re-read and
 * re-decoded the index and a month file, which grew quadratically with the inbox.
 * Any write through this layer drops the cached copy.
 */
function &fi_json_cache(): array
{
    static $cache = [];
    return $cache;
}

function fi_json_read_cached(string $relativePath, mixed $default = []): mixed
{
    $cache = &fi_json_cache();
    if (!array_key_exists($relativePath, $cache)) {
        $cache[$relativePath] = fi_json_read($relativePath, $default);
    }
    return $cache[$relativePath];
}

function fi_json_read(string $relativePath, mixed $default = []): mixed
{
    $path = fi_storage_root($relativePath);
    if (!is_file($path)) {
        return $default;
    }
    $raw = file_get_contents($path);
    if ($raw === false || trim($raw) === '') {
        return $default;
    }
    $decoded = json_decode($raw, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        fi_preserve_corrupt_json($path, json_last_error_msg());
        throw new RuntimeException('Stored JSON could not be decoded.');
    }
    return $decoded;
}

function fi_json_write_locked(string $relativePath, mixed $value): void
{
    $lockPath = fi_lock_path($relativePath);
    $lock = fopen($lockPath, 'c');
    if ($lock === false) {
        throw new RuntimeException('Could not open storage lock.');
    }
    try {
        if (!flock($lock, LOCK_EX)) {
            throw new RuntimeException('Could not lock storage file.');
        }
        fi_json_write_unlocked($relativePath, $value);
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
}

function fi_json_update_locked(string $relativePath, callable $callback, mixed $default = []): mixed
{
    $lockPath = fi_lock_path($relativePath);
    $lock = fopen($lockPath, 'c');
    if ($lock === false) {
        throw new RuntimeException('Could not open storage lock.');
    }
    try {
        if (!flock($lock, LOCK_EX)) {
            throw new RuntimeException('Could not lock storage file.');
        }
        $current = fi_json_read($relativePath, $default);
        $updated = $callback($current);
        fi_json_write_unlocked($relativePath, $updated);
        return $updated;
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
}

function fi_json_write_unlocked(string $relativePath, mixed $value): void
{
    $cache = &fi_json_cache();
    unset($cache[$relativePath]);
    $path = fi_storage_root($relativePath);
    $dir = dirname($path);
    if (!is_dir($dir)) {
        mkdir($dir, 0775, true);
    }

    // INVALID_UTF8_SUBSTITUTE: one stray byte in a visitor's message must never make a
    // whole submission unsaveable.
    $json = json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    if ($json === false) {
        throw new RuntimeException('Could not encode JSON.');
    }
    json_decode($json, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new RuntimeException('Encoded JSON did not validate.');
    }

    $tmp = $path . '.tmp.' . bin2hex(random_bytes(4));
    $handle = fopen($tmp, 'wb');
    if ($handle === false) {
        throw new RuntimeException('Could not create temporary storage file.');
    }
    try {
        if (fwrite($handle, $json . "\n") === false) {
            throw new RuntimeException('Could not write temporary storage file.');
        }
        fflush($handle);
    } finally {
        fclose($handle);
    }
    if (!rename($tmp, $path)) {
        @unlink($tmp);
        throw new RuntimeException('Could not replace storage file atomically.');
    }
}

function fi_preserve_corrupt_json(string $path, string $reason): void
{
    $copy = $path . '.corrupt-' . gmdate('YmdHis');
    @copy($path, $copy);
    fi_log('error', 'Corrupt JSON preserved: ' . basename($path) . ' (' . $reason . ')');
}

function fi_log(string $level, string $message): void
{
    $dir = fi_storage_root('logs');
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    $path = $dir . '/app.log';
    if (is_file($path) && filesize($path) > 1048576) {
        @rename($path, $dir . '/app-' . gmdate('YmdHis') . '.log');
    }
    $line = '[' . fi_now() . '] ' . strtoupper($level) . ' ' . preg_replace('/[\r\n]+/', ' ', $message) . PHP_EOL;
    @file_put_contents($path, $line, FILE_APPEND | LOCK_EX);
}
