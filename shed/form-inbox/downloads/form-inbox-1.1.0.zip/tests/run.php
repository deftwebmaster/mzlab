<?php

declare(strict_types=1);

// Command line only: this file must never do anything when requested over the web.
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

// Run against a temporary storage directory so the suite can never touch live data.
// (In 1.0.0 this file wrote into the real storage folder and could be requested by anyone.)
define('FI_TEST_STORAGE', sys_get_temp_dir() . '/form-inbox-tests-' . bin2hex(random_bytes(4)));

require_once __DIR__ . '/../includes/bootstrap.php';

$failures = 0;
function ok(bool $condition, string $label): void
{
    global $failures;
    echo ($condition ? 'PASS ' : 'FAIL ') . $label . PHP_EOL;
    if (!$condition) {
        $failures++;
    }
}

function test_submission(string $formId, string $status, string $bucket, string $updatedAt, array $fields = ['message' => 'hello']): array
{
    $submission = [
        'id' => fi_random_id('sub'), 'form_id' => $formId, 'status' => $status,
        'received_at' => $updatedAt, 'updated_at' => $updatedAt, 'fields' => $fields, 'attachments' => [],
        'notification_status' => 'disabled',
    ];
    fi_submission_store($submission, $bucket);
    return $submission;
}

// --- storage ---------------------------------------------------------------------
$testFile = 'data/tests-' . bin2hex(random_bytes(3)) . '.json';
fi_json_write_locked($testFile, ['hello' => 'world']);
ok(fi_json_read($testFile, [])['hello'] === 'world', 'locked JSON write/read');
fi_json_update_locked($testFile, static function (array $data): array {
    $data['count'] = 2;
    return $data;
}, []);
ok(fi_json_read($testFile, [])['count'] === 2, 'locked JSON update');
ok(fi_json_read_cached($testFile, [])['count'] === 2, 'cached read sees current data');
fi_json_update_locked($testFile, static fn(array $data): array => ['count' => 3], []);
ok(fi_json_read_cached($testFile, [])['count'] === 3, 'a write drops the cached copy');
ok(is_file(fi_storage_root('.htaccess')), 'private storage gets a deny rule');

// --- validation ------------------------------------------------------------------
$form = fi_form_defaults(['name' => 'Test Form', 'slug' => 'test-form', 'public_token' => 'fi_pub_test', 'field_schema' => ['email' => ['type' => 'email', 'required' => true]], 'field_mode' => 'schema']);
[$fields, $errors] = fi_normalize_submission_fields(['email' => 'person@example.com', '_form_token' => 'fi_pub_test'], $form);
ok($errors === [] && $fields['email'] === 'person@example.com', 'schema email validation accepts valid email');
[, $errors] = fi_normalize_submission_fields(['email' => 'bad'], $form);
ok(isset($errors['email']), 'schema email validation rejects invalid email');

$emptySchema = fi_form_defaults(['name' => 'Empty', 'slug' => 'empty', 'field_mode' => 'schema', 'field_schema' => []]);
[$fields] = fi_normalize_submission_fields(['name' => 'Ada', 'message' => 'Hi'], $emptySchema);
ok(($fields['message'] ?? '') === 'Hi', 'schema mode with no schema keeps the submitted fields');

$flexible = fi_form_defaults(['name' => 'Flex', 'slug' => 'flex']);
[$fields] = fi_normalize_submission_fields(['message' => "caf\xE9 au lait"], $flexible);
ok($fields['message'] !== '' && preg_match('//u', $fields['message']) === 1, 'invalid UTF-8 is scrubbed, not blanked');
ok(str_starts_with($fields['message'], 'caf'), 'the readable part of the value survives');
$long = str_repeat('é', 15000); // 30,000 bytes
[$fields, $errors] = fi_normalize_submission_fields(['message' => $long], $flexible);
ok(preg_match('//u', $fields['message']) === 1 && strlen($fields['message']) <= (int) fi_config('maximum_field_bytes'), 'long values are cut on a character boundary');
ok(json_encode($fields) !== false, 'truncated values still encode as JSON');
ok(fi_truncate_utf8('aé', 2) === 'a', 'truncation never splits a multi-byte character');

// --- spam ------------------------------------------------------------------------
ok(fi_csv_safe('=SUM(A1:A2)')[0] === "'", 'CSV formula values are prefixed');
[$score, $reasons] = fi_spam_score(['message' => 'HTTP://A HTTP://B HTTP://C HTTP://D'], $form);
ok($score >= 3 && in_array('many_links', $reasons, true), 'spam score counts excessive links');
[, $reasons] = fi_spam_score(['message' => 'BUY NOW THE VERY BEST DEALS ON EVERYTHING YOU COULD POSSIBLY WANT TODAY'], $flexible);
ok(in_array('excessive_uppercase', $reasons, true), 'shouting is scored as excessive uppercase');
[, $reasons] = fi_spam_score(['message' => 'Hello, I would like to ask about your opening hours next week please.'], $flexible);
ok(!in_array('excessive_uppercase', $reasons, true), 'ordinary text is not');

// --- mail headers ----------------------------------------------------------------
ok(fi_mail_encode('Plain subject') === 'Plain subject', 'ASCII subjects are left alone');
ok(str_starts_with(fi_mail_encode('Café enquiry'), '=?UTF-8?B?'), 'non-ASCII subjects are RFC 2047 encoded');
ok(!str_contains(fi_notification_subject("Hi {name}", $flexible, ['fields' => ['name' => "A\r\nBcc: x@example.com"]]), "\n"), 'subject placeholders cannot inject headers');

// --- forms -----------------------------------------------------------------------
$first = fi_form_create(fi_form_defaults(['name' => 'First', 'slug' => 'first']));
$second = fi_form_create(fi_form_defaults(['name' => 'Second', 'slug' => 'second']));
$clash = false;
try {
    fi_form_update((string) $first['id'], array_replace($first, ['slug' => 'second']));
} catch (Throwable) {
    $clash = true;
}
ok($clash, 'a form cannot take the slug of a form listed after it');

// --- inbox -----------------------------------------------------------------------
$formId = (string) $first['id'];
$old = gmdate('Y-m-d\\TH:i:s\\Z', time() - 90 * 86400);
$recent = fi_now();
$kept = test_submission($formId, 'new', 'submissions', $recent);
$trashedOld = test_submission($formId, 'deleted', 'submissions', $old);
$trashedNew = test_submission($formId, 'deleted', 'submissions', $recent);
$spamOld = test_submission($formId, 'spam', 'spam', $old);
$rescued = test_submission($formId, 'read', 'spam', $old); // filed as spam, then marked "not spam"

$inbox = fi_submission_list([], 1, 25);
$ids = array_column($inbox['items'], 'id');
ok(in_array($kept['id'], $ids, true) && in_array($rescued['id'], $ids, true), 'inbox lists ordinary and rescued submissions');
ok(!in_array($trashedNew['id'], $ids, true) && !in_array($spamOld['id'], $ids, true), 'inbox leaves spam and trash out');
ok(count(fi_submission_list(['status' => 'deleted'], 1, 25)['items']) === 2, 'trash view lists trashed submissions');
ok(fi_submission_counts()['total'] === 2, 'dashboard totals leave spam and trash out');

// --- maintenance -----------------------------------------------------------------
ob_start();
require __DIR__ . '/../bin/maintenance.php';
$output = (string) ob_get_clean();
ok(str_contains($output, 'Removed 2 expired record(s)'), 'maintenance removes exactly the expired trash and spam');
ok(fi_submission_find($rescued['id']) !== null, 'a message rescued from spam is never purged');
ok(fi_submission_find($kept['id']) !== null, 'ordinary submissions are kept');
ok(fi_submission_find($trashedOld['id']) === null, 'trash older than the retention period is emptied');
ok(fi_submission_find($trashedNew['id']) !== null, 'recent trash is kept');
ok(fi_submission_find($spamOld['id']) === null, 'old spam is removed');

// --- install path ----------------------------------------------------------------
foreach ([
    '/inbox/index.php' => '/inbox',
    '/inbox/submit.php' => '/inbox',
    '/inbox/admin/index.php' => '/inbox',
    '/inbox/admin/actions/form-create.php' => '/inbox',
    '/admin/actions/form-update.php' => '',
    '/submit.php' => '',
] as $script => $expected) {
    ok(fi_install_path($script) === $expected, 'install root resolves from ' . $script);
}

echo ($failures > 0 ? $failures . ' test(s) failed.' : 'All tests passed.') . PHP_EOL;
exit($failures > 0 ? 1 : 0);
