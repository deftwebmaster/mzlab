<?php
declare(strict_types=1);
?>
<section class="panel">
    <h2>Configuration</h2>
    <dl class="settings-list">
        <dt>Base URL</dt><dd><?php echo dv_e(dv_base_url() ?: 'Auto-detected'); ?></dd>
        <dt>Timezone</dt><dd><?php echo dv_e(dv_config('timezone')); ?></dd>
        <dt>Storage path</dt><dd><?php echo is_writable((string) dv_config('storage_path')) ? 'Writable' : 'Not writable'; ?></dd>
        <dt>Private files path</dt><dd><?php echo is_writable((string) dv_config('files_path')) ? 'Writable' : 'Not writable'; ?></dd>
        <dt>Import path</dt><dd><?php echo is_writable((string) dv_config('import_path')) ? 'Writable' : 'Not writable'; ?></dd>
        <dt>Configured upload limit</dt><dd><?php echo dv_e(dv_format_bytes((int) dv_config('max_upload_bytes'))); ?></dd>
        <dt>PHP upload_max_filesize</dt><dd><?php echo dv_e((string) ini_get('upload_max_filesize')); ?></dd>
        <dt>PHP post_max_size</dt><dd><?php echo dv_e((string) ini_get('post_max_size')); ?></dd>
        <dt>Estimated unique downloads</dt><dd><?php echo dv_config('estimate_unique_downloads') ? 'On (' . (int) dv_config('unique_window_hours', 168) . '-hour window)' : 'Off'; ?></dd>
        <dt>Version</dt><dd><?php echo dv_e(DV_VERSION); ?></dd>
        <dt>Password helper</dt><dd><?php echo is_file(DV_ROOT . '/tools/generate-password.php') ? 'Present - delete after setup' : 'Removed'; ?></dd>
    </dl>
</section>
<section class="panel">
    <h2>Private Directory Check</h2>
    <p class="muted">Uploaded files and data must never be readable straight from the web. This asks your server for a marker file in each private directory; a blocked request is the result you want.</p>
    <dl class="settings-list">
        <?php foreach (['storage_path' => 'Storage', 'files_path' => 'Private files', 'import_path' => 'Import'] as $key => $label): $probe = dv_probe_url($key); ?>
            <dt><?php echo dv_e($label); ?></dt>
            <dd<?php echo $probe ? ' data-probe="' . dv_e($probe) . '"' : ''; ?>><?php echo $probe ? 'Checking...' : 'Outside the web root - protected'; ?></dd>
        <?php endforeach; ?>
    </dl>
</section>
<section class="panel">
    <h2>Export Data</h2>
    <p class="muted">Download Vault stores records in JSON under the configured storage directory. Use Backups to create a safe restore point before large changes.</p>
    <a class="button" href="<?php echo dv_e(dv_url('admin/actions/export.php?type=downloads')); ?>">Download records JSON</a>
    <a class="button" href="<?php echo dv_e(dv_url('admin/actions/export.php?type=daily-stats')); ?>">Daily stats JSON</a>
    <a class="button" href="<?php echo dv_e(dv_url('admin/actions/export.php?type=history-csv')); ?>">History CSV</a>
</section>
