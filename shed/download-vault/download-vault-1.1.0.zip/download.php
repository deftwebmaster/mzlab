<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
dv_security_headers('public');

$slug = (string) dv_get('slug', '');
if ($slug === '' && isset($_SERVER['PATH_INFO'])) {
    $slug = trim((string) $_SERVER['PATH_INFO'], '/');
}
$slug = dv_slugify($slug);

if ($slug === '') {
    dv_rate_limit_check('invalid-slug', dv_request_id('invalid-slug'), 20, 900);
    dv_public_error('This download link was not found.', 404, 'Link not found');
}

$download = dv_download_find_by_slug($slug);
if (!$download) {
    dv_rate_limit_check('invalid-slug', dv_request_id('invalid-slug'), 20, 900);
    dv_public_error('This download link was not found.', 404, 'Link not found');
}

$status = dv_download_status($download);
if ($status['code'] !== 'active') {
    $map = [
        'disabled' => ['This download is not currently available.', 404, 'Download unavailable', 'disabled'],
        'archived' => ['This download is not currently available.', 404, 'Download unavailable', 'disabled'],
        'expired' => ['This download link has expired.', 410, 'Download expired', 'expired'],
        'limit_reached' => ['This download limit has been reached.', 403, 'Download limit reached', 'limit_reached'],
        'missing_file' => ['This download is temporarily unavailable.', 404, 'Download unavailable', 'missing_file'],
    ];
    [$message, $code, $title, $result] = $map[$status['code']] ?? ['This download is unavailable.', 404, 'Download unavailable', 'blocked'];
    dv_history_add((string) $download['id'], $result);
    dv_public_error($message, $code, $title);
}

$requiresPassword = !empty($download['password_hash']);
$authorized = !$requiresPassword || dv_download_authorized($download);
$passwordError = '';

$method = (string) ($_SERVER['REQUEST_METHOD'] ?? 'GET');

if ($method === 'POST' && $requiresPassword) {
    $tokenOk = true;
    try {
        dv_verify_csrf();
    } catch (Throwable) {
        // The page sat open past the session lifetime (or cookies are blocked). Saying
        // "password not accepted" here sent people off to re-check a correct password.
        $tokenOk = false;
        http_response_code(200);
        $passwordError = 'This page had expired. Please enter the password again.';
    }
    if ($tokenOk) {
        $identifier = dv_request_id('download-password-' . $download['id']);
        if (!dv_rate_limit_check('download-password', $identifier, 10, 900, false)) {
            dv_history_add((string) $download['id'], 'rate_limited');
            dv_public_error('Too many attempts. Please wait before trying again.', 429, 'Too many attempts');
        }
        if (password_verify((string) dv_post('download_password'), (string) $download['password_hash'])) {
            dv_download_grant($download);
            $authorized = true;
        } else {
            dv_rate_limit_check('download-password', $identifier, 10, 900); // only wrong guesses count
            dv_history_add((string) $download['id'], 'invalid_password');
            $passwordError = 'The password was not accepted.';
        }
    }
}

$wantsFile = (string) dv_get('download') === '1' || (empty($download['landing_page_enabled']) && !$requiresPassword);

// Link checkers, chat-app previews and mail scanners probe URLs with HEAD. Answer with
// the file's headers but do not count a download or spend one of a limited number.
if ($authorized && $wantsFile && $method === 'HEAD') {
    dv_stream_file($download, true);
}

if ($authorized && $wantsFile) {
    $identifier = dv_request_id('download-start');
    if (!dv_rate_limit_check('download-start', $identifier, 30, 60)) {
        dv_history_add((string) $download['id'], 'rate_limited');
        dv_public_error('Too many downloads were requested too quickly.', 429, 'Too many attempts');
    }
    try {
        $reserved = dv_download_reserve_start((string) $download['id']);
        dv_stream_file($reserved);
    } catch (Throwable $e) {
        dv_log_error('Download stream reservation failed: ' . $e->getMessage());
        dv_public_error('This download is no longer available.', 403, 'Download unavailable');
    }
}

include DV_ROOT . '/templates/public-download.php';
