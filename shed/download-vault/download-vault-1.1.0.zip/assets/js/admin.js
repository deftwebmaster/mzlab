(function () {
    function randomSlug() {
        var alphabet = 'abcdefghjkmnpqrstuvwxyz23456789';
        var slug = '';
        for (var i = 0; i < 8; i += 1) {
            slug += alphabet[Math.floor(Math.random() * alphabet.length)];
        }
        return slug;
    }

    document.addEventListener('click', function (event) {
        var randomButton = event.target.closest('[data-random-slug]');
        if (randomButton) {
            var input = document.querySelector('#slug');
            if (input) {
                input.value = randomSlug();
                input.focus();
            }
        }

        var copyButton = event.target.closest('[data-copy]');
        if (copyButton) {
            var text = copyButton.getAttribute('data-copy');
            var done = function (ok) {
                var original = copyButton.getAttribute('data-label') || copyButton.textContent;
                copyButton.setAttribute('data-label', original);
                copyButton.textContent = ok ? 'Copied' : 'Press Ctrl+C';
                window.setTimeout(function () { copyButton.textContent = original; }, 1400);
            };
            // navigator.clipboard only exists on HTTPS; fall back so Copy still works on
            // a plain-http or intranet install instead of silently doing nothing.
            var legacyCopy = function () {
                var area = document.createElement('textarea');
                area.value = text;
                area.setAttribute('readonly', '');
                area.style.position = 'fixed';
                area.style.opacity = '0';
                document.body.appendChild(area);
                area.select();
                var ok = false;
                try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
                document.body.removeChild(area);
                done(ok);
            };
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(text).then(function () { done(true); }, legacyCopy);
            } else {
                legacyCopy();
            }
        }
    });

    // Settings page: can the browser read the marker file in each private directory?
    document.querySelectorAll('[data-probe]').forEach(function (cell) {
        fetch(cell.getAttribute('data-probe'), { cache: 'no-store', credentials: 'omit' }).then(function (response) {
            return response.ok ? response.text() : '';
        }).then(function (body) {
            if (body.indexOf('download-vault-access-probe') !== -1) {
                cell.textContent = 'EXPOSED - this directory can be read from the web. Move it outside the web root or block it in your server configuration.';
                cell.className = 'probe-bad';
            } else {
                cell.textContent = 'Blocked - protected';
                cell.className = 'probe-good';
            }
        }).catch(function () {
            cell.textContent = 'Blocked - protected';
            cell.className = 'probe-good';
        });
    });

    document.addEventListener('submit', function (event) {
        var form = event.target;
        var message = form.getAttribute('data-confirm');
        if (message && !window.confirm(message)) {
            event.preventDefault();
        }
    });

    document.addEventListener('input', function (event) {
        if (!event.target.matches('[data-table-search]')) {
            return;
        }
        var query = event.target.value.toLowerCase();
        var table = document.querySelector('[data-searchable]');
        if (!table) {
            return;
        }
        table.querySelectorAll('tbody tr').forEach(function (row) {
            row.hidden = query !== '' && row.textContent.toLowerCase().indexOf(query) === -1;
        });
    });
}());
