# Changelog

## 1.1.0 - 2026-11-16

Maintenance release from ManicZone Lab. Drop-in upgrade: replace the application files and keep your `config.php` and private directories. No data migration is needed.

### Fixed

- Admin forms redirected to a non-existent `admin/actions/admin/...` address whenever `base_url` was left empty, which is how `config.php` ships. The install path is now detected correctly from every entry point.
- The login lockout counted successful logins, so five ordinary logins inside 15 minutes locked the administrator out. Only failed attempts count now, a successful login clears them, and the login page says when a lockout is in effect.
- `HEAD` requests (link checkers, chat previews, mail scanners) were counted as downloads and used up limited links. They now receive the file headers without counting.
- A long transfer held the PHP session lock and froze every other page for that visitor until it finished. The session is released before streaming, the time limit is lifted for the transfer, and streaming stops when the visitor disconnects.
- An expired form or an upload larger than `post_max_size` produced a generic "Something went wrong" page. Admin actions now return to the right page with a clear message, and upload errors say which limit was hit.
- A download password submitted from an expired page was reported as a wrong password.
- The Copy button did nothing on plain-HTTP installs, where the browser clipboard API is unavailable.
- CSV export raised a deprecation error on PHP 8.4 with strict error reporting.
- A mistyped `timezone` in `config.php` no longer breaks the whole install; it falls back to UTC.
- An unreadable expiration date now gives a plain explanation instead of a raw PHP message.
- A stored file is removed again if its download record cannot be saved.

### Changed

- `inline_extensions` is now enforced. With "Force download" off, only the listed types open in the browser; everything else (including SVG and XML) is still sent as a download.
- `estimate_unique_downloads` now actually produces an estimate, shown on each download's statistics page, using `unique_window_hours`.
- `accent_color` and `support_url` from `config.php` are now applied.
- Only wrong download passwords count toward the password rate limit.
- History CSV cells that begin with `=`, `+`, `-` or `@` are neutralised so spreadsheets do not run them as formulas.

### Added

- Settings page check that asks your server for a marker file in each private directory and warns loudly if it can be read from the web.
- `.htaccess` rules blocking direct requests to `includes/`, `templates/`, `tests/`, `config.php` and `VERSION`; matching Nginx rules in the README.
- The test suite refuses to run over the web, and covers the fixes above.

## 1.0.0 - 2026-07-28

- Initial Download Vault release.
- Added single-admin authentication, protected uploads, import-directory registration, clean download links, landing/direct delivery, password protection, expiration, maximum download limits, daily stats, history, backups, and documentation.
