# Security Policy

## Supported Versions

Version 1.x is the supported release line. Always run the newest 1.x release; 1.1.0 fixes a login lockout problem and tightens file delivery.

## Reporting Issues

Report vulnerabilities to ManicZone Lab through the Download Vault page at https://lab.maniczone.com/shed/download-vault/. Do not post exploit details publicly until a fixed release is available.

## Deployment Recommendations

- Put `storage_path`, `files_path`, and `import_path` outside the public web root whenever possible.
- Delete `tools/generate-password.php` after creating your administrator password hash.
- Change `privacy_salt` before launch.
- Use HTTPS for admin access and download links.
- After setup and after any server change, open Settings and confirm the Private Directory Check shows every directory as blocked. On Nginx, add the `deny` rules from the README; `.htaccess` files have no effect there.
- Keep PHP updated. Download Vault requires PHP 8.2 or newer.
- Secret URLs are convenient, but they are not a substitute for passwords on sensitive files.

Download Vault does not store plaintext passwords, raw session IDs, full referrer URLs, or raw IP addresses by default. Estimated unique download tracking is disabled by default and uses salted hashes.
