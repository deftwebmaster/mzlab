<?php
declare(strict_types=1);

function dv_admin_logged_in(): bool
{
    $loggedIn = !empty($_SESSION['admin_authenticated']);
    if (!$loggedIn) {
        return false;
    }
    $timeout = max(1, (int) dv_config('session_timeout_minutes', 30)) * 60;
    $last = (int) ($_SESSION['admin_last_seen'] ?? 0);
    if ($last > 0 && time() - $last > $timeout) {
        dv_admin_logout();
        return false;
    }
    $_SESSION['admin_last_seen'] = time();
    return true;
}

/** True while this visitor has used up their failed-login allowance (5 in 15 minutes). */
function dv_admin_login_locked(): bool
{
    return !dv_rate_limit_check('admin-login', dv_request_id('admin-login'), 5, 900, false);
}

function dv_admin_login(string $password): bool
{
    $identifier = dv_request_id('admin-login');
    // Only failures count. Counting every attempt locked the real administrator out
    // after five ordinary logins in a quarter of an hour.
    if (!dv_rate_limit_check('admin-login', $identifier, 5, 900, false)) {
        return false;
    }
    $hash = (string) dv_config('admin_password_hash', '');
    if ($hash === '' || $hash === 'REPLACE_WITH_PASSWORD_HASH') {
        return false;
    }
    if (!password_verify($password, $hash)) {
        dv_rate_limit_check('admin-login', $identifier, 5, 900);
        return false;
    }
    dv_rate_limit_clear('admin-login', $identifier);
    if (session_status() === PHP_SESSION_ACTIVE && !headers_sent()) {
        session_regenerate_id(true);
    }
    $_SESSION['admin_authenticated'] = true;
    $_SESSION['admin_last_seen'] = time();
    return true;
}

function dv_admin_logout(): void
{
    unset($_SESSION['admin_authenticated'], $_SESSION['admin_last_seen']);
}

function dv_require_admin(): void
{
    if (!dv_admin_logged_in()) {
        dv_redirect(dv_url('admin/login.php'));
    }
}

/**
 * Gate for admin/actions/*.php: signed in, a POST, and a valid security token.
 * Problems send the administrator back with an explanation instead of the generic
 * "Something went wrong" page the uncaught token error used to produce.
 */
function dv_require_admin_action(string $returnTo = 'admin/?page=downloads'): void
{
    dv_require_admin();
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        dv_redirect(dv_url($returnTo));
    }
    // A body bigger than post_max_size arrives with $_POST and $_FILES both empty,
    // which would otherwise look exactly like a missing security token.
    $limit = dv_post_max_bytes();
    $length = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($_POST === [] && $limit > 0 && $length > $limit) {
        dv_flash('That upload is larger than this server accepts in one request (post_max_size is ' . ini_get('post_max_size') . '). Use the import directory for large files.', 'danger');
        dv_redirect(dv_url($returnTo));
    }
    try {
        dv_verify_csrf();
    } catch (Throwable) {
        http_response_code(200);
        dv_flash('That form had expired. Nothing was changed - please try again.', 'danger');
        dv_redirect(dv_url($returnTo));
    }
}
