<?php
declare(strict_types=1);

$GLOBALS['DV_CONFIG'] = [];

function dv_configure(array $config): void
{
    $GLOBALS['DV_CONFIG'] = $config;
    $timezone = (string) dv_config('timezone', 'UTC');
    // A mistyped timezone in config.php used to take the whole install down with a notice.
    if ($timezone === '' || !in_array($timezone, timezone_identifiers_list(DateTimeZone::ALL_WITH_BC), true)) {
        $timezone = 'UTC';
        $GLOBALS['DV_CONFIG']['timezone'] = 'UTC';
    }
    date_default_timezone_set($timezone);
}

function dv_config(?string $key = null, mixed $default = null): mixed
{
    if ($key === null) {
        return $GLOBALS['DV_CONFIG'];
    }
    return $GLOBALS['DV_CONFIG'][$key] ?? $default;
}

function dv_e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function dv_now(): string
{
    return gmdate('Y-m-d\TH:i:s\Z');
}

function dv_local_time(?string $iso, string $fallback = 'Never'): string
{
    if (!$iso) {
        return $fallback;
    }
    try {
        $date = new DateTimeImmutable($iso);
        return $date->setTimezone(new DateTimeZone((string) dv_config('timezone', 'UTC')))->format('M j, Y g:i A');
    } catch (Throwable) {
        return $fallback;
    }
}

function dv_date_input(?string $iso): string
{
    if (!$iso) {
        return '';
    }
    try {
        $date = new DateTimeImmutable($iso);
        return $date->setTimezone(new DateTimeZone((string) dv_config('timezone', 'UTC')))->format('Y-m-d\TH:i');
    } catch (Throwable) {
        return '';
    }
}

function dv_input_to_utc(?string $value): ?string
{
    $value = trim((string) $value);
    if ($value === '') {
        return null;
    }
    try {
        $date = new DateTimeImmutable($value, new DateTimeZone((string) dv_config('timezone', 'UTC')));
    } catch (Throwable) {
        throw new InvalidArgumentException('The expiration date was not understood. Use the date picker or the format YYYY-MM-DD HH:MM.');
    }
    return $date->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d\TH:i:s\Z');
}

function dv_format_bytes(int|float $bytes): string
{
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $size = max(0, (float) $bytes);
    $unit = 0;
    while ($size >= 1024 && $unit < count($units) - 1) {
        $size /= 1024;
        $unit++;
    }
    return ($unit === 0 ? (string) (int) $size : number_format($size, 1)) . ' ' . $units[$unit];
}

function dv_id(string $prefix): string
{
    return $prefix . '_' . gmdate('YmdHis') . '_' . bin2hex(random_bytes(5));
}

function dv_base_url(): string
{
    $configured = rtrim((string) dv_config('base_url', ''), '/');
    if ($configured !== '') {
        return $configured;
    }
    if (PHP_SAPI === 'cli') {
        return '';
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ((int) ($_SERVER['SERVER_PORT'] ?? 80) === 443);
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return ($https ? 'https://' : 'http://') . $host . dv_install_path((string) ($_SERVER['SCRIPT_NAME'] ?? ''));
}

/**
 * URL path of the install root, worked out from the running script's own path.
 * Without "admin/actions" in the list, every admin form posted to admin/actions/*.php
 * redirected to .../admin/actions/admin/... whenever base_url was left empty (the
 * shipped default).
 */
function dv_install_path(string $scriptName): string
{
    $scriptDir = str_replace('\\', '/', dirname($scriptName));
    $scriptDir = preg_replace('#/(admin/actions|admin|tools|tests)$#', '', $scriptDir) ?? '';
    return rtrim($scriptDir, '/');
}

function dv_url(string $path = ''): string
{
    return rtrim(dv_base_url(), '/') . '/' . ltrim($path, '/');
}

function dv_public_download_url(string $slug): string
{
    if (dv_config('routing_mode', 'rewrite') === 'fallback') {
        return dv_url('download.php?slug=' . rawurlencode($slug));
    }
    return dv_url('d/' . rawurlencode($slug));
}

function dv_redirect(string $url): never
{
    header('Location: ' . $url, true, 303);
    exit;
}

function dv_post(string $key, mixed $default = ''): mixed
{
    return $_POST[$key] ?? $default;
}

function dv_get(string $key, mixed $default = ''): mixed
{
    return $_GET[$key] ?? $default;
}

function dv_bool_from_post(string $key): bool
{
    return isset($_POST[$key]) && in_array((string) $_POST[$key], ['1', 'on', 'yes', 'true'], true);
}

function dv_slugify(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9_-]+/', '-', $value) ?? '';
    $value = trim(preg_replace('/-+/', '-', $value) ?? '', '-_');
    return $value;
}

function dv_flash(?string $message = null, string $type = 'success'): ?array
{
    if ($message !== null) {
        $_SESSION['flash'] = ['message' => $message, 'type' => $type];
        return null;
    }
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return is_array($flash) ? $flash : null;
}

function dv_log_error(string $message, array $context = []): void
{
    $path = $GLOBALS['DV_CONFIG']['storage_path'] ?? (defined('DV_ROOT') ? DV_ROOT . '/storage' : sys_get_temp_dir());
    $logDir = rtrim((string) $path, '/\\') . '/logs';
    if (!is_dir($logDir)) {
        @mkdir($logDir, 0755, true);
    }
    $line = dv_now() . ' ' . $message;
    if ($context !== []) {
        $line .= ' ' . json_encode($context, JSON_UNESCAPED_SLASHES);
    }
    $file = $logDir . '/app.log';
    if (@is_file($file) && @filesize($file) > 1048576) {
        @rename($file, $logDir . '/app-' . gmdate('YmdHis') . '.log');
    }
    @file_put_contents($file, $line . PHP_EOL, FILE_APPEND | LOCK_EX);
}

/** Validated accent colour for the --accent CSS variable, or '' to keep the stylesheet default. */
function dv_accent_style(): string
{
    $color = trim((string) dv_config('accent_color', ''));
    if (!preg_match('/^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $color) || strtolower($color) === '#2563eb') {
        return '';
    }
    return ' style="--accent: ' . dv_e($color) . '; --accent-strong: ' . dv_e($color) . '"';
}

/**
 * Public URL of a private directory's probe file when that directory sits inside the
 * web root, or null when it has been moved outside it (the recommended layout).
 * The Settings page fetches these: a probe that can be read means the web server is
 * not applying the bundled .htaccess rules and private data is exposed.
 */
function dv_probe_url(string $configKey): ?string
{
    $dir = realpath((string) dv_config($configKey, ''));
    $root = realpath(DV_ROOT);
    if (!$dir || !$root || !str_starts_with($dir . DIRECTORY_SEPARATOR, $root . DIRECTORY_SEPARATOR)) {
        return null;
    }
    if (!is_file($dir . '/access-probe.txt')) {
        @file_put_contents($dir . '/access-probe.txt', "download-vault-access-probe\n");
    }
    $relative = trim(str_replace('\\', '/', substr($dir, strlen($root))), '/');
    return dv_url($relative . '/access-probe.txt');
}

/** Bytes PHP will accept in one request body, or 0 when unlimited. */
function dv_post_max_bytes(): int
{
    $raw = trim((string) ini_get('post_max_size'));
    if ($raw === '' || $raw === '0') {
        return 0;
    }
    $value = (float) $raw;
    return (int) match (strtolower(substr($raw, -1))) {
        'g' => $value * 1073741824,
        'm' => $value * 1048576,
        'k' => $value * 1024,
        default => $value,
    };
}

function dv_validate_config(): void
{
    foreach (['storage_path', 'files_path', 'import_path'] as $key) {
        $path = (string) dv_config($key, '');
        if ($path === '') {
            throw new RuntimeException('Configuration value ' . $key . ' is required.');
        }
        if (!is_dir($path) && !mkdir($path, 0755, true)) {
            throw new RuntimeException('Directory could not be created: ' . $key);
        }
    }
    foreach (['backups', 'locks', 'logs'] as $dir) {
        $path = rtrim((string) dv_config('storage_path'), '/\\') . '/' . $dir;
        if (!is_dir($path)) {
            @mkdir($path, 0755, true);
        }
    }
}
