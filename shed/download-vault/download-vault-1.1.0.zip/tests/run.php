<?php
declare(strict_types=1);

// Command line only: this file must never do anything when requested over the web.
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/includes/bootstrap.php';

$tmp = sys_get_temp_dir() . '/download-vault-tests-' . bin2hex(random_bytes(4));
mkdir($tmp . '/storage/backups', 0755, true);
mkdir($tmp . '/storage/locks', 0755, true);
mkdir($tmp . '/storage/logs', 0755, true);
mkdir($tmp . '/files', 0755, true);
mkdir($tmp . '/import', 0755, true);

dv_configure(array_replace(dv_config(), [
    'storage_path' => $tmp . '/storage',
    'files_path' => $tmp . '/files',
    'import_path' => $tmp . '/import',
    'admin_password_hash' => password_hash('secret', PASSWORD_DEFAULT),
    'privacy_salt' => 'test-salt',
]));

function test_assert(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException('Test failed: ' . $message);
    }
    echo "ok - " . $message . PHP_EOL;
}

$store = dv_storage_update('downloads', static function (array $data): array {
    $data['downloads'] = [];
    return $data;
});
test_assert(($store['schema_version'] ?? null) === 1, 'storage writes schema version');

$sample = $tmp . '/files/f_sample.txt';
file_put_contents($sample, 'hello');
$record = dv_download_save([
    'slug' => 'sample-file',
    'title' => 'Sample File',
    'stored_filename' => 'f_sample.txt',
    'original_filename' => 'sample.txt',
    'file_size' => 5,
    'mime_type' => 'text/plain',
    'file_hash' => hash_file('sha256', $sample),
    'maximum_downloads' => 1,
    'landing_page_enabled' => true,
    'force_download' => true,
], true);
test_assert(dv_download_find_by_slug('sample-file') !== null, 'download can be found by slug');

$reserved = dv_download_reserve_start((string) $record['id']);
test_assert((int) $reserved['download_count'] === 1, 'first download start increments counter');

$blocked = false;
try {
    dv_download_reserve_start((string) $record['id']);
} catch (Throwable) {
    $blocked = true;
}
test_assert($blocked, 'download limit blocks second reservation');

dv_create_backup('downloads');
test_assert(count(dv_list_backups('downloads')) >= 1, 'backup creation works');

[$slug, $errors] = dv_validate_slug('../admin');
test_assert($errors !== [], 'reserved or unsafe slug is rejected');
test_assert(dv_validate_filename('shell.php.jpg') !== [], 'double extension executable upload is rejected');

$history = dv_history_recent((string) $record['id']);
test_assert($history !== [] && ($history[0]['result'] ?? '') === 'success', 'successful download writes history');

// --- 1.1.0 regressions ---------------------------------------------------------

// Only failed logins count toward the lockout, and a success clears them.
$_SERVER['REMOTE_ADDR'] = '203.0.113.9';
for ($i = 0; $i < 8; $i++) {
    test_assert(dv_admin_login('secret') === true, 'correct admin login #' . ($i + 1) . ' is accepted');
    dv_admin_logout();
}
for ($i = 0; $i < 5; $i++) {
    dv_admin_login('wrong');
}
test_assert(dv_admin_login_locked() === true, 'five wrong passwords lock the login');
test_assert(dv_admin_login('secret') === false, 'a locked login refuses even the right password');

// Browser display is limited to the configured inline types.
dv_configure(array_replace(dv_config(), ['inline_extensions' => ['pdf', 'png', 'txt']]));
test_assert(dv_delivery_mode(['force_download' => true, 'original_filename' => 'a.pdf']) === 'attachment', 'force download always sends an attachment');
test_assert(dv_delivery_mode(['force_download' => false, 'original_filename' => 'a.pdf']) === 'inline', 'pdf may open in the browser');
test_assert(dv_delivery_mode(['force_download' => false, 'original_filename' => 'a.svg']) === 'attachment', 'svg is never shown inline');
test_assert(dv_delivery_mode(['force_download' => false, 'original_filename' => 'a.pdf', 'custom_filename' => 'x.html']) === 'attachment', 'custom filename decides the delivery type');

// The install root is found from every entry point when base_url is left empty.
foreach ([
    '/vault/index.php' => '/vault',
    '/vault/download.php' => '/vault',
    '/vault/admin/index.php' => '/vault',
    '/vault/admin/actions/create.php' => '/vault',
    '/vault/tools/generate-password.php' => '/vault',
    '/admin/actions/update.php' => '',
    '/index.php' => '',
] as $script => $expected) {
    test_assert(dv_install_path($script) === $expected, 'install root resolves from ' . $script);
}

// Unique estimate counts a visitor once inside the window.
dv_configure(array_replace(dv_config(), ['estimate_unique_downloads' => true, 'unique_window_hours' => 24]));
$uniqueRecord = dv_download_save([
    'slug' => 'unique-file', 'title' => 'Unique File', 'stored_filename' => 'f_sample.txt',
    'original_filename' => 'sample.txt', 'file_size' => 5, 'mime_type' => 'text/plain', 'file_hash' => '',
], true);
$_SERVER['REMOTE_ADDR'] = '198.51.100.20';
dv_download_reserve_start((string) $uniqueRecord['id']);
dv_download_reserve_start((string) $uniqueRecord['id']);
$_SERVER['REMOTE_ADDR'] = '192.0.2.77';
$afterTwoVisitors = dv_download_reserve_start((string) $uniqueRecord['id']);
test_assert((int) $afterTwoVisitors['download_count'] === 3, 'three starts are counted');
test_assert((int) (dv_download_find((string) $uniqueRecord['id'])['unique_download_count'] ?? 0) === 2, 'two visitors are estimated as two unique downloads');

test_assert(dv_post_max_bytes() >= 0, 'post_max_size is readable');

echo "All tests passed." . PHP_EOL;
