<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
// Logging out is always safe to honour; a stale token just means the session moved on.
try {
    dv_verify_csrf();
} catch (Throwable) {
    http_response_code(200);
}
dv_admin_logout();
dv_redirect(dv_url('admin/login.php'));
