<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
dv_require_admin_action('admin/?page=downloads');

try {
    dv_download_toggle((string) dv_post('id'));
    dv_flash('Download status changed.');
} catch (Throwable $e) {
    dv_flash($e->getMessage(), 'danger');
}
dv_redirect(dv_url('admin/?page=downloads'));
