<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';
dv_require_admin_action('admin/?page=create');

try {
    $record = dv_download_from_form();
    $source = (string) dv_post('file_source', 'upload');
    if ($source === 'import') {
        $file = dv_store_import_file((string) dv_post('import_file'));
    } else {
        $file = dv_store_uploaded_file($_FILES['download_file'] ?? []);
    }
    $record += $file;
    try {
        dv_download_save($record, true);
    } catch (Throwable $e) {
        @unlink(dv_private_file_path((string) $file['stored_filename']));
        throw $e;
    }
    dv_flash('Download created.');
    dv_redirect(dv_url('admin/?page=downloads'));
} catch (Throwable $e) {
    dv_flash($e->getMessage(), 'danger');
    dv_redirect(dv_url('admin/?page=create'));
}
