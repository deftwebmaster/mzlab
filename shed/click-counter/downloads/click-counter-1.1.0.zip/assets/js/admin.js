(function () {
    const name = document.querySelector('[data-slug-source]');
    const slug = document.querySelector('[data-slug-target]');
    if (name && slug) {
        let touched = Boolean(slug.value);
        slug.addEventListener('input', () => { touched = true; });
        name.addEventListener('input', () => {
            if (touched) return;
            slug.value = name.value.toLowerCase()
                .replace(/[^a-z0-9_-]+/g, '-')
                .replace(/^-+|-+$/g, '')
                .replace(/-+/g, '-');
        });
    }

    // navigator.clipboard only exists on HTTPS; fall back so Copy still works on a
    // plain-http or intranet install instead of silently doing nothing.
    const legacyCopy = (text) => {
        const area = document.createElement('textarea');
        area.value = text;
        area.setAttribute('readonly', '');
        area.style.position = 'fixed';
        area.style.opacity = '0';
        document.body.appendChild(area);
        area.select();
        let ok = false;
        try { ok = document.execCommand('copy'); } catch (_) { ok = false; }
        document.body.removeChild(area);
        return ok;
    };
    document.querySelectorAll('[data-copy]').forEach((button) => {
        const label = button.textContent;
        button.addEventListener('click', async () => {
            const text = button.getAttribute('data-copy') || '';
            let ok = false;
            if (navigator.clipboard && window.isSecureContext) {
                try { await navigator.clipboard.writeText(text); ok = true; } catch (_) { ok = false; }
            }
            if (!ok) ok = legacyCopy(text);
            button.textContent = ok ? 'Copied' : 'Press Ctrl+C';
            setTimeout(() => { button.textContent = label; }, 1400);
        });
    });

    // Destructive forms ask first.
    document.querySelectorAll('form[data-confirm]').forEach((form) => {
        form.addEventListener('submit', (event) => {
            if (!window.confirm(form.getAttribute('data-confirm'))) event.preventDefault();
        });
    });

    // Diagnostics: can the browser read the marker file inside private storage?
    document.querySelectorAll('[data-probe]').forEach((cell) => {
        const verdict = (exposed) => {
            cell.textContent = exposed
                ? 'EXPOSED - private storage can be read from the web. Move it outside the web root or block it in your server configuration.'
                : 'Blocked - private storage cannot be read from the web.';
            const badge = cell.closest('.diagnostic') && cell.closest('.diagnostic').querySelector('strong');
            if (badge) {
                badge.textContent = exposed ? 'Failure' : 'Pass';
                badge.className = exposed ? 'failure' : 'pass';
            }
        };
        fetch(cell.getAttribute('data-probe'), { cache: 'no-store', credentials: 'omit' })
            .then((response) => (response.ok ? response.text() : ''))
            .then((body) => verdict(body.indexOf('click-counter-access-probe') !== -1))
            .catch(() => verdict(false));
    });

    const search = document.querySelector('[data-table-search]');
    if (search) {
        const rows = Array.from(document.querySelectorAll('[data-search-row]'));
        search.addEventListener('input', () => {
            const q = search.value.toLowerCase();
            rows.forEach((row) => {
                row.hidden = !(row.getAttribute('data-search-row') || '').toLowerCase().includes(q);
            });
        });
    }
})();
