(function () {
    // Public counter embed for Click Counter (ManicZone Lab).
    // <span data-click-count="my-slug" data-prefix="Downloaded " data-suffix=" times">-</span>
    var script = document.currentScript;
    if (!script || !script.src) return;
    var elements = Array.prototype.slice.call(document.querySelectorAll('[data-click-count]'));
    if (!elements.length) return;

    var base = new URL(script.src, window.location.href);
    var root = base.origin + base.pathname.replace(/\/assets\/js\/counter\.js$/, '');
    var slugs = [];
    elements.forEach(function (el) {
        var slug = (el.getAttribute('data-click-count') || '').trim().toLowerCase();
        if (slug && slugs.indexOf(slug) === -1) slugs.push(slug);
    });
    if (!slugs.length) return;

    // One request for every counter on the page, through the query-string endpoint so it
    // works whether or not the server has URL rewriting switched on.
    for (var i = 0; i < slugs.length; i += 50) {
        (function (batch) {
            fetch(root + '/api/counts.php?slugs=' + encodeURIComponent(batch.join(',')), { credentials: 'omit' })
                .then(function (response) { return response.ok ? response.json() : null; })
                .then(function (data) {
                    if (!data || !data.counts) return;
                    elements.forEach(function (el) {
                        var slug = (el.getAttribute('data-click-count') || '').trim().toLowerCase();
                        if (!Object.prototype.hasOwnProperty.call(data.counts, slug)) return;
                        var count = Number(data.counts[slug]) || 0;
                        var shown = el.hasAttribute('data-plain') ? String(count) : count.toLocaleString();
                        el.textContent = (el.getAttribute('data-prefix') || '') + shown + (el.getAttribute('data-suffix') || '');
                    });
                })
                .catch(function () { /* leave the placeholder text in place */ });
        }(slugs.slice(i, i + 50)));
    }
})();
