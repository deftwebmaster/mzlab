<?php

declare(strict_types=1);

// Command line only: this file must never do anything when requested over the web.
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

// Run against a temporary storage directory so the suite can never touch live data.
define('CC_TEST_STORAGE', sys_get_temp_dir() . '/click-counter-tests-' . bin2hex(random_bytes(4)));

require_once __DIR__ . '/../includes/bootstrap.php';

function cc_test(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException('Test failed: ' . $message);
    }
    echo 'ok - ' . $message . PHP_EOL;
}

function cc_test_link(string $slug, array $overrides = []): array
{
    $link = cc_link_payload(array_replace([
        'name' => 'Test ' . $slug,
        'slug' => $slug,
        'description' => '',
        'type' => 'redirect',
        'destination_url' => 'https://example.com/',
        'status' => 'active',
        'redirect_status' => 302,
        'public_counter_enabled' => true,
        'expires_at' => null,
        'maximum_clicks' => null,
        'deduplication_seconds' => 0,
        'bot_mode' => 'count_all',
        'track_referrer' => false,
        'track_device' => false,
        'estimate_unique' => false,
        'notes' => '',
    ], $overrides));
    cc_save_link($link);
    return $link;
}

$_SERVER['REMOTE_ADDR'] = '203.0.113.10';

// HEAD requests and prefetches resolve the link but are not clicks.
cc_test_link('head-check', ['maximum_clicks' => 2]);
$_SERVER['REQUEST_METHOD'] = 'HEAD';
$result = cc_handle_request('head-check', ['redirect']);
cc_test($result['ok'] === true && $result['counted'] === false, 'HEAD resolves the link without counting');
$_SERVER['REQUEST_METHOD'] = 'GET';
$_SERVER['HTTP_SEC_PURPOSE'] = 'prefetch;prerender';
$result = cc_handle_request('head-check', ['redirect']);
cc_test($result['ok'] === true && $result['counted'] === false, 'browser prefetch resolves the link without counting');
unset($_SERVER['HTTP_SEC_PURPOSE']);
cc_test((int) cc_find_link_by_slug('head-check')['total_clicks'] === 0, 'neither request used up the limited link');
cc_handle_request('head-check', ['redirect']);
cc_handle_request('head-check', ['redirect']);
$result = cc_handle_request('head-check', ['redirect']);
cc_test($result['ok'] === false && $result['status'] === 'limit_reached', 'real clicks still stop at the limit');
cc_test((int) cc_find_link_by_slug('head-check')['total_clicks'] === 2, 'exactly two clicks were counted');

// Editing a link must keep its expiration: the form now pre-fills the stored value.
$stored = '2031-03-04T15:30:00Z';
$input = cc_to_local_input($stored);
cc_test($input !== '', 'a stored expiration becomes a form value');
[$errors, $validated] = cc_validate_link_input([
    'name' => 'Round Trip', 'slug' => 'round-trip', 'type' => 'redirect',
    'destination_url' => 'https://example.com/', 'expires_at' => $input,
]);
cc_test($errors === [] && $validated['expires_at'] === $stored, 'saving the form again keeps the same expiration');
cc_test(cc_to_local_input($input) === $input, 'a value the form just posted is shown unchanged');
cc_test(cc_to_local_input('not a date') === '', 'an unreadable date becomes an empty field');

// Only passive file types may be shown in the browser.
cc_test(cc_inline_safe('application/pdf'), 'pdf may be shown inline');
cc_test(cc_inline_safe('image/png'), 'png may be shown inline');
cc_test(!cc_inline_safe('image/svg+xml'), 'svg is never shown inline');
cc_test(!cc_inline_safe('text/html; charset=utf-8'), 'html is never shown inline');

// The install root is found from every entry point.
foreach ([
    '/cc/index.php' => '/cc',
    '/cc/redirect.php' => '/cc',
    '/cc/admin/index.php' => '/cc',
    '/cc/admin/actions/link-create.php' => '/cc',
    '/cc/api/count.php' => '/cc',
    '/cc/tools/generate-password.php' => '/cc',
    '/admin/actions/link-update.php' => '',
    '/index.php' => '',
] as $script => $expected) {
    cc_test(cc_install_path($script) === $expected, 'install root resolves from ' . $script);
}

// Unique-click hashes are pruned even when deduplication is off.
cc_test_link('unique-only', ['estimate_unique' => true]);
cc_update_json('visitor-hashes', static function (array &$data): void {
    $data['records']['unique_stale'] = ['link_id' => 'x', 'expires_at' => time() - 10];
});
cc_handle_request('unique-only', ['redirect']);
$records = cc_read_json('visitor-hashes')['records'] ?? [];
cc_test(!isset($records['unique_stale']), 'expired visitor hashes are removed on the next counted click');
cc_test((int) cc_find_link_by_slug('unique-only')['estimated_unique_clicks'] === 1, 'a first visitor is estimated as one unique click');
cc_handle_request('unique-only', ['redirect']);
cc_test((int) cc_find_link_by_slug('unique-only')['estimated_unique_clicks'] === 1, 'the same visitor is not counted as unique twice');

// Only failed logins count toward the lockout.
cc_test(!cc_login_is_rate_limited(), 'login starts unlocked');
for ($i = 0; $i < (int) cc_config('login_max_attempts'); $i++) {
    cc_login_register_failure();
}
cc_test(cc_login_is_rate_limited(), 'repeated failures lock the login');
cc_login_clear_failures();
cc_test(!cc_login_is_rate_limited(), 'clearing failures unlocks it');

// CSV cells that look like formulas are neutralised.
cc_test(cc_csv_cell('=SUM(A1)') === "'=SUM(A1)", 'formula-like CSV cells are escaped');
cc_test(cc_csv_cell('plain') === 'plain', 'ordinary CSV cells are untouched');

echo "All regression tests passed.\n";
