<?php

declare(strict_types=1);

// Command line only: this file must never do anything when requested over the web.
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

// Run against a temporary storage directory so the suite can never touch live data.
// (In 1.0.0 these files used the real storage and could be requested by anyone.)
define('CC_TEST_STORAGE', sys_get_temp_dir() . '/click-counter-tests-' . bin2hex(random_bytes(4)));

require_once __DIR__ . '/../includes/bootstrap.php';

$backup = cc_create_backup('test');
if (!is_file(cc_storage_path('backups/' . $backup))) {
    throw new RuntimeException('Backup was not created.');
}
[$ok] = cc_validate_redirect_url('javascript:alert(1)');
if ($ok) {
    throw new RuntimeException('Unsafe URL was accepted.');
}
[$ok] = cc_validate_redirect_url('https://example.com/path?a=1');
if (!$ok) {
    throw new RuntimeException('Safe HTTPS URL was rejected.');
}
echo "Storage smoke test passed.\n";
