<?php

declare(strict_types=1);

// Command line only: this file must never do anything when requested over the web.
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

// Run against a temporary storage directory so the suite can never touch live data.
// (In 1.0.0 these files used the real storage and could be requested by anyone.)
define('CC_TEST_STORAGE', sys_get_temp_dir() . '/click-counter-tests-' . bin2hex(random_bytes(4)));

require_once __DIR__ . '/../includes/bootstrap.php';

$slug = 'stress-' . strtolower(bin2hex(random_bytes(3)));
$link = cc_link_payload([
    'name' => 'Stress Test',
    'slug' => $slug,
    'description' => '',
    'type' => 'redirect',
    'destination_url' => 'https://example.com/',
    'status' => 'active',
    'redirect_status' => 302,
    'public_counter_enabled' => true,
    'expires_at' => null,
    'maximum_clicks' => 25,
    'deduplication_seconds' => 0,
    'bot_mode' => 'count_all',
    'track_referrer' => false,
    'track_device' => false,
    'estimate_unique' => false,
    'notes' => '',
]);
cc_save_link($link);
for ($i = 0; $i < 40; $i++) {
    cc_count_request($slug, ['redirect']);
}
$saved = cc_find_link_by_slug($slug);
if (!$saved || (int) $saved['total_clicks'] !== 25) {
    throw new RuntimeException('Maximum-click limit was not enforced.');
}
echo "Counter limit test passed.\n";
