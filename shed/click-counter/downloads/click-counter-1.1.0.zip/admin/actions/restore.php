<?php

declare(strict_types=1);

require_once __DIR__ . '/../../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_require_csrf();

try {
    cc_restore_backup((string) ($_POST['name'] ?? ''));
    cc_flash('Backup restored. The data it replaced was backed up first.');
} catch (Throwable $e) {
    cc_flash('That backup could not be restored: ' . $e->getMessage(), 'error');
}
header('Location: ' . cc_base_url('admin/backups.php'));
exit;
