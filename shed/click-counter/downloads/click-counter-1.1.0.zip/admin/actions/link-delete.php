<?php

declare(strict_types=1);

require_once __DIR__ . '/../../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_require_csrf();

$id = (string) ($_POST['id'] ?? '');
if (!cc_find_link_by_id($id)) {
    cc_admin_error('The requested link was not found.', 404);
}
cc_delete_link($id, cc_bool_from_post('delete_stats'), cc_bool_from_post('delete_file'));
cc_flash('Link deleted. A backup was saved first.');
header('Location: ' . cc_base_url('admin/links.php'));
exit;
