<?php

declare(strict_types=1);

require_once __DIR__ . '/../../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_require_csrf();

$upload = $_FILES['import'] ?? [];
if (($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file((string) ($upload['tmp_name'] ?? ''))) {
    cc_admin_error('Choose a Click Counter backup JSON file to import.', 400);
}
$data = json_decode((string) file_get_contents((string) $upload['tmp_name']), true);
if (!is_array($data)) {
    cc_admin_error('That file is not readable JSON, so nothing was imported.', 400);
}
if (($data['schema_version'] ?? null) !== 1 || !is_array($data['data'] ?? null)) {
    cc_admin_error('The import file is not a valid Click Counter backup.', 400);
}
foreach (['links', 'daily-stats', 'recent-events'] as $name) {
    if (!is_array($data['data'][$name] ?? null)) {
        cc_admin_error('The import file is missing required data.', 400);
    }
}
if (!is_array($data['data']['links']['links'] ?? null)) {
    cc_admin_error('The import file does not contain a list of links.', 400);
}
cc_create_backup('before-import');
cc_with_lock('data', static function () use ($data): void {
    foreach (['links', 'daily-stats', 'recent-events'] as $name) {
        cc_atomic_write_json(cc_json_path($name), $data['data'][$name]);
    }
});
cc_flash('Import completed.');
header('Location: ' . cc_base_url('admin/links.php'));
exit;
