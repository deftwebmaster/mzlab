<?php

declare(strict_types=1);

require_once __DIR__ . '/../../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_require_csrf();

$id = (string) ($_POST['id'] ?? '');
$mode = (string) ($_POST['mode'] ?? 'all');
if (!cc_find_link_by_id($id)) {
    cc_admin_error('The requested link was not found.', 404);
}
cc_create_backup('before-reset-counter');
cc_update_json('links', static function (array &$data) use ($id): void {
    // Write through the index. The 1.0.0 loop iterated "($data['links'] ?? []) as &$link",
    // which hands PHP a temporary copy, so the totals it zeroed were thrown away and
    // Reset only ever cleared the daily chart.
    foreach (($data['links'] ?? []) as $index => $link) {
        if (($link['id'] ?? '') === $id) {
            $data['links'][$index]['total_clicks'] = 0;
            $data['links'][$index]['estimated_unique_clicks'] = 0;
            $data['links'][$index]['last_clicked_at'] = null;
            $data['links'][$index]['updated_at'] = cc_now();
        }
    }
});
// Forget this link's visitor hashes too, so unique estimates start clean with the counter.
cc_update_json('visitor-hashes', static function (array &$data) use ($id): void {
    foreach (($data['records'] ?? []) as $key => $record) {
        if (($record['link_id'] ?? '') === $id) {
            unset($data['records'][$key]);
        }
    }
});
if ($mode === 'all' || $mode === 'daily') {
    cc_update_json('daily-stats', static function (array &$data) use ($id): void {
        unset($data['links'][$id]);
    });
}
cc_flash('Counter reset.');
header('Location: ' . cc_base_url('admin/link-stats.php?id=' . rawurlencode($id)));
exit;
