<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';
cc_start_session();
cc_require_admin();
cc_send_admin_headers();

function cc_diag(string $label, string $status, string $detail): array
{
    return ['label' => $label, 'status' => $status, 'detail' => $detail];
}

$checks = [];
$checks[] = cc_diag('PHP version', PHP_VERSION_ID >= 80200 ? 'pass' : 'failure', PHP_VERSION . ' detected; PHP 8.2 or newer is required.');
$checks[] = cc_diag('JSON support', function_exists('json_encode') ? 'pass' : 'failure', 'JSON functions are required for flat-file storage.');
$checks[] = cc_diag('Session support', function_exists('session_start') ? 'pass' : 'failure', 'PHP sessions are required for administrator login.');
$checks[] = cc_diag('Fileinfo extension', function_exists('finfo_open') ? 'pass' : 'warning', 'Fileinfo improves protected upload MIME detection.');
foreach ([
    'Storage' => cc_config('storage_path'),
    'Private files' => cc_config('files_path'),
    'Backups' => cc_storage_path('backups'),
    'Locks' => cc_storage_path('locks'),
    'Temporary' => cc_storage_path('temporary'),
] as $label => $path) {
    $checks[] = cc_diag($label . ' writable', is_writable((string) $path) ? 'pass' : 'failure', (string) $path);
}
$checks[] = cc_diag('Password configured', cc_password_configured() ? 'pass' : 'failure', 'Set admin_password_hash in config.php.');
$checks[] = cc_diag('Password helper', is_file(cc_root_path('tools/generate-password.php')) ? 'warning' : 'pass', 'Delete tools/generate-password.php after setup.');
$checks[] = cc_diag('HTTPS', (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'pass' : 'warning', 'Use HTTPS on production admin pages.');
$configuredBase = rtrim((string) cc_config('base_url'), '/');
$effectiveBase = rtrim(cc_base_url(), '/');
$checks[] = cc_diag('Base URL', filter_var($effectiveBase, FILTER_VALIDATE_URL) ? ($configuredBase === $effectiveBase ? 'pass' : 'warning') : 'failure',
    $configuredBase === $effectiveBase ? $effectiveBase : $effectiveBase . ' (detected from this request - set base_url in config.php to fix it in place)');
$storageReal = realpath((string) cc_config('storage_path'));
$rootReal = realpath(cc_root_path());
$probeUrl = null;
if ($storageReal && $rootReal && str_starts_with($storageReal . DIRECTORY_SEPARATOR, $rootReal . DIRECTORY_SEPARATOR)) {
    if (!is_file($storageReal . '/access-probe.txt')) {
        @file_put_contents($storageReal . '/access-probe.txt', "click-counter-access-probe\n");
    }
    $probeUrl = cc_base_url(trim(str_replace('\\', '/', substr($storageReal, strlen($rootReal))), '/') . '/access-probe.txt');
}
$checks[] = $probeUrl
    ? cc_diag('Private storage blocked', 'warning', 'Checking...') + ['probe' => $probeUrl]
    : cc_diag('Private storage blocked', 'pass', 'Storage is outside the web root.');
$checks[] = cc_diag('Timezone', @timezone_open((string) cc_config('timezone')) ? 'pass' : 'failure', (string) cc_config('timezone'));
foreach (['links', 'daily-stats', 'recent-events', 'rate-limits', 'visitor-hashes', 'settings'] as $name) {
    try {
        $data = cc_read_json($name);
        $checks[] = cc_diag($name . '.json', (($data['schema_version'] ?? null) === 1) ? 'pass' : 'warning', 'Schema version ' . cc_h($data['schema_version'] ?? 'missing'));
    } catch (Throwable $e) {
        $checks[] = cc_diag($name . '.json', 'failure', 'Could not read valid JSON.');
    }
}
$checks[] = cc_diag('Version', 'pass', 'Click Counter ' . cc_version());
$checks[] = cc_diag('Upload limit', 'pass', 'upload_max_filesize=' . ini_get('upload_max_filesize') . ', post_max_size=' . ini_get('post_max_size'));
ob_start();
?>
<div class="page-head"><div><h1>Diagnostics</h1><p class="muted">Practical checks for shared hosting setup, writable storage, and PHP features.</p></div></div>
<section class="panel">
    <?php foreach ($checks as $check): ?>
        <div class="diagnostic">
            <strong class="<?= cc_h($check['status']) ?>"><?= cc_h(ucfirst($check['status'])) ?></strong>
            <div><b><?= cc_h($check['label']) ?></b><br><span class="muted"<?= isset($check['probe']) ? ' data-probe="' . cc_h($check['probe']) . '"' : '' ?>><?= cc_h($check['detail']) ?></span></div>
        </div>
    <?php endforeach; ?>
</section>
<?php
$content = ob_get_clean();
$pageTitle = 'Diagnostics';
require cc_root_path('templates/admin-layout.php');
