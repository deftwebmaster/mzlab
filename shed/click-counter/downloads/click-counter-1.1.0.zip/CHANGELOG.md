# Changelog

## 1.1.0 - 2026-11-16

Maintenance release from ManicZone Lab. Drop-in upgrade: replace the application files and keep your `config.php` and private storage. No data migration is needed.

### Fixed

- **Editing a link erased its expiration.** The edit form always showed an empty expiration field, so saving any change removed the date. The field is now pre-filled with the stored value.
- **Reset counter did not reset the total.** It cleared the daily chart but left the total and unique counts as they were. It now zeroes them, and clears that link's visitor hashes.
- **A fresh install pointed at `http://localhost:8000`.** `base_url` shipped preset to a local test address, so stylesheets, links and redirects broke until `config.php` was edited. An empty `base_url` (the new default) is detected from each request; the old placeholder is treated the same way.
- **Test and maintenance scripts could be run by anyone over the web.** `tests/` created links and backups in live data, and repeated requests could push real backups out of retention. Everything in `tests/` and `bin/` is now command-line only, the tests use a temporary directory, and `.htaccess` blocks those folders.
- `HEAD` requests and browser prefetches were counted as clicks and used up limited links. They now get the redirect or file headers without counting.
- Uploading a file on a form that had another error left an orphaned copy in private storage on every attempt. Replacing a protected file left the old one behind. Both are cleaned up.
- Links that only used "Estimate unique clicks" grew `visitor-hashes.json` without limit. Expired hashes are pruned on every counted click.
- An expired login form showed a full error page with the admin navigation; it now re-shows the login form. The login page says when a lockout is in effect.
- An upload larger than `post_max_size` was reported as an expired security token. Upload errors now name the limit that was hit.
- Importing a file that was not valid JSON left a stray copy in the system temp directory and gave a generic error.
- The Copy button did nothing on plain-HTTP installs and relabelled "Copy URL" buttons as "Copy".
- CSV export raised a deprecation notice on PHP 8.4.
- Duplicating a link whose file could not be copied produced a link to a file that did not exist.
- The bundled storage `.htaccess` files caused a server error on Apache 2.4 without `mod_access_compat`.

### Changed

- "Allow inline viewing" now applies only to PDF, raster images, audio, video and plain text. SVG, HTML and other active types are always sent as downloads.
- The public counter embed makes one request for all counters on a page, formats numbers for the visitor's locale (add `data-plain` to opt out), and works with or without URL rewriting.
- `api/counts.php` accepts up to 50 slugs per request.
- Protected downloads lift the PHP time limit for the transfer and stop when the visitor disconnects.
- Reset and Delete ask for confirmation. Delete reports an unknown link instead of claiming success.
- Estimated unique clicks are shown on a link's statistics page when enabled.

### Added

- Diagnostics check that asks your server for a marker file in private storage and reports a failure if it can be read from the web.
- Diagnostics shows the detected base URL and the installed version.
- `tests/regressions.php` covering the fixes above.

### Removed

- `IMPLEMENTATION_REPORT.md`, an internal build note that described the code as untested. The README, this changelog and the test suite replace it.

## 1.0.0 - 2026-07-28

- Initial Click Counter release.
- Added flat-file JSON storage, safe redirects, download counting, protected local downloads, admin login, CSRF protection, backups, diagnostics, public counters, CSV export, and documentation.
