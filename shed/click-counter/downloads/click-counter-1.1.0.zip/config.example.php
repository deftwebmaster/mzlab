<?php

declare(strict_types=1);

return [
    'app_name' => 'Click Counter',
    'tagline' => 'Simple click and download tracking for your own website.',
    // Full address of this folder, e.g. https://example.com/click-counter (no trailing slash).
    // Leave empty to have Click Counter work it out from each request.
    'base_url' => '',
    'timezone' => 'America/Chicago',

    'admin_password_hash' => 'REPLACE_WITH_PASSWORD_HASH',
    'session_timeout_minutes' => 30,
    'login_max_attempts' => 5,
    'login_window_seconds' => 900,

    'storage_path' => __DIR__ . '/private-storage',
    'files_path' => __DIR__ . '/private-storage/files',

    'default_redirect_status' => 302,
    'default_bot_mode' => 'count_all',
    'default_deduplication_seconds' => 0,

    'track_referrer_domains' => true,
    'track_device_category' => false,
    'estimate_unique_clicks' => false,
    'store_raw_ip' => false,

    'recent_activity_limit' => 1000,
    'backup_retention' => 10,
    'maximum_upload_bytes' => 104857600,

    'public_counter_cors' => 'disabled',
    'allowed_counter_origins' => [],

    'routing_mode' => 'rewrite',
    'allow_mailto_tel' => false,
    'debug' => false,

    'branding' => [
        'accent_color' => '#2563eb',
        'homepage_url' => '',
        'support_url' => '',
        'documentation_url' => '',
        'admin_footer' => 'Click Counter is free PHP software from ManicZone Lab.',
        'public_unavailable_text' => 'This tracked link is unavailable.',
        'show_public_attribution' => true,
    ],
];
