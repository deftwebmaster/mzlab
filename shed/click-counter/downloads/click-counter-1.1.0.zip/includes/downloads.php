<?php

declare(strict_types=1);

function cc_protected_file_path(string $storedFilename): ?string
{
    // Protected downloads never trust stored or requested paths directly. Both
    // the configured files directory and candidate file are resolved before use.
    if ($storedFilename === '' || str_contains($storedFilename, '..') || preg_match('/[\/\\\\\x00-\x1F]/', $storedFilename)) {
        return null;
    }
    $base = realpath((string) cc_config('files_path'));
    if ($base === false) {
        return null;
    }
    $candidate = $base . DIRECTORY_SEPARATOR . $storedFilename;
    $real = realpath($candidate);
    if ($real === false || !str_starts_with($real, $base . DIRECTORY_SEPARATOR)) {
        return null;
    }
    if (!is_file($real) || is_link($real) || !is_readable($real)) {
        return null;
    }
    return $real;
}

function cc_store_uploaded_file(array $upload): array
{
    [$ok, $meta, $error] = cc_validate_upload($upload);
    if (!$ok || !is_array($meta)) {
        throw new RuntimeException($error);
    }
    $target = rtrim((string) cc_config('files_path'), '/') . '/' . $meta['stored_filename'];
    if (!move_uploaded_file((string) $meta['tmp_name'], $target)) {
        throw new RuntimeException('The uploaded file could not be moved into private storage.');
    }
    @chmod($target, 0640);
    $meta['sha256'] = hash_file('sha256', $target) ?: '';
    return $meta;
}

/** MIME types a browser may display in place. Anything else is always sent as a download. */
function cc_inline_safe(string $mime): bool
{
    $mime = strtolower(trim(explode(';', $mime)[0]));
    if (in_array($mime, ['application/pdf', 'text/plain'], true)) {
        return true;
    }
    // Raster images, audio and video are passive. SVG, HTML and XML can run script.
    return (bool) preg_match('#^(image/(png|jpe?g|gif|webp|avif|bmp)|audio/[\w.+-]+|video/[\w.+-]+)$#', $mime);
}

function cc_stream_protected_download(array $link): never
{
    $path = cc_protected_file_path((string) ($link['stored_filename'] ?? ''));
    if (!$path) {
        cc_public_error('Unavailable download', 'This download is not available.', 404);
    }
    $filename = cc_safe_filename((string) ($link['original_filename'] ?? 'download'));
    $mime = str_replace(["\r", "\n"], '', (string) (($link['mime_type'] ?? '') ?: 'application/octet-stream'));
    $disposition = (!empty($link['allow_inline']) && empty($link['force_download']) && cc_inline_safe($mime)) ? 'inline' : 'attachment';

    // Long transfers must not be cut off by max_execution_time, and output compression
    // would make the Content-Length below wrong.
    if (function_exists('set_time_limit')) {
        @set_time_limit(0);
    }
    @ini_set('zlib.output_compression', '0');
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . (string) filesize($path));
    header('Content-Disposition: ' . $disposition . '; filename="' . addcslashes($filename, "\"\\") . '"');
    header('X-Content-Type-Options: nosniff');
    header('Accept-Ranges: none');
    header('Cache-Control: private, no-store');
    header('Pragma: no-cache');
    header('Expires: 0');
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'HEAD') {
        exit;
    }
    $handle = fopen($path, 'rb');
    if ($handle === false) {
        cc_log('Protected file stream failed.');
        exit;
    }
    while (!feof($handle) && !connection_aborted()) {
        $buffer = fread($handle, 1048576);
        if ($buffer === false) {
            break;
        }
        echo $buffer;
        flush();
    }
    fclose($handle);
    exit;
}

/** Remove a stored protected file once no link refers to it any more. */
function cc_delete_file_if_unused(string $storedFilename): void
{
    if ($storedFilename === '') {
        return;
    }
    foreach (cc_all_links() as $link) {
        if (($link['stored_filename'] ?? '') === $storedFilename) {
            return;
        }
    }
    if ($path = cc_protected_file_path($storedFilename)) {
        @unlink($path);
    }
}
