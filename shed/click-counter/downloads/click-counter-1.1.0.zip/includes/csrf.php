<?php

declare(strict_types=1);

function cc_csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return (string) $_SESSION['csrf_token'];
}

function cc_csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . cc_h(cc_csrf_token()) . '">';
}

function cc_require_csrf(): void
{
    $limit = cc_post_max_bytes();
    if ($_POST === [] && $limit > 0 && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > $limit) {
        cc_admin_error('That upload is larger than this server accepts in one request (post_max_size is ' . ini_get('post_max_size') . '). Nothing was changed.', 413);
    }
    $token = (string) ($_POST['csrf_token'] ?? '');
    if ($token === '' || empty($_SESSION['csrf_token']) || !hash_equals((string) $_SESSION['csrf_token'], $token)) {
        cc_admin_error('The form could not be accepted because its security token expired. Please try again.', 403);
    }
}

/** Same check as cc_require_csrf(), but returns the verdict instead of ending the request. */
function cc_csrf_valid(): bool
{
    $token = (string) ($_POST['csrf_token'] ?? '');
    return $token !== '' && !empty($_SESSION['csrf_token']) && hash_equals((string) $_SESSION['csrf_token'], $token);
}
