<?php

declare(strict_types=1);

function cc_root_path(string $path = ''): string
{
    $root = dirname(__DIR__);
    return $path === '' ? $root : $root . '/' . ltrim($path, '/');
}

function cc_version(): string
{
    return trim((string) @file_get_contents(cc_root_path('VERSION'))) ?: '1.1.0';
}

function cc_h(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function cc_now(): string
{
    return gmdate('Y-m-d\TH:i:s\Z');
}

function cc_today_key(?string $timezone = null): string
{
    $tz = new DateTimeZone($timezone ?: cc_config('timezone'));
    return (new DateTimeImmutable('now', $tz))->format('Y-m-d');
}

function cc_to_local(?string $utc): string
{
    if (!$utc) {
        return 'Never';
    }
    try {
        $dt = new DateTimeImmutable($utc, new DateTimeZone('UTC'));
        return $dt->setTimezone(new DateTimeZone(cc_config('timezone')))->format('Y-m-d H:i');
    } catch (Throwable) {
        return 'Invalid date';
    }
}

function cc_base_url(string $path = ''): string
{
    static $base = null;
    if ($base === null) {
        $base = rtrim((string) cc_config('base_url'), '/');
        // 1.0.0 shipped with base_url preset to http://localhost:8000, so a fresh upload
        // sent every stylesheet, link and redirect to the visitor's own machine until
        // config.php was edited. An empty value, or that old placeholder on any other
        // host, is now detected from the request instead.
        $host = (string) ($_SERVER['HTTP_HOST'] ?? '');
        $placeholder = $base === 'http://localhost:8000' && $host !== '' && $host !== 'localhost:8000';
        if (($base === '' || $placeholder) && PHP_SAPI !== 'cli' && $host !== '') {
            $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (int) ($_SERVER['SERVER_PORT'] ?? 80) === 443;
            $base = ($https ? 'https://' : 'http://') . $host . cc_install_path((string) ($_SERVER['SCRIPT_NAME'] ?? ''));
        }
    }
    return $base . '/' . ltrim($path, '/');
}

/** URL path of the install root, worked out from the running script's own path. */
function cc_install_path(string $scriptName): string
{
    $dir = str_replace('\\', '/', dirname($scriptName));
    $dir = preg_replace('#/(admin/actions|admin|api|tools|bin|tests)$#', '', $dir) ?? '';
    return rtrim($dir, '/');
}

/** Value for a datetime-local input from a stored UTC timestamp (or a value the form just posted). */
function cc_to_local_input(?string $value): string
{
    $value = trim((string) $value);
    if ($value === '') {
        return '';
    }
    try {
        $zone = new DateTimeZone((string) cc_config('timezone'));
        $isUtc = str_ends_with($value, 'Z');
        $dt = new DateTimeImmutable($value, $isUtc ? new DateTimeZone('UTC') : $zone);
        return $dt->setTimezone($zone)->format('Y-m-d\TH:i');
    } catch (Throwable) {
        return '';
    }
}

/** True when the browser or a proxy is only pre-loading the page, not following a click. */
function cc_is_prefetch(): bool
{
    foreach (['HTTP_SEC_PURPOSE', 'HTTP_PURPOSE', 'HTTP_X_PURPOSE', 'HTTP_X_MOZ'] as $header) {
        $value = strtolower((string) ($_SERVER[$header] ?? ''));
        if ($value !== '' && (str_contains($value, 'prefetch') || str_contains($value, 'prerender') || str_contains($value, 'preview'))) {
            return true;
        }
    }
    return false;
}

/** Bytes PHP will accept in one request body, or 0 when unlimited. */
function cc_post_max_bytes(): int
{
    $raw = trim((string) ini_get('post_max_size'));
    if ($raw === '' || $raw === '0') {
        return 0;
    }
    $value = (float) $raw;
    return (int) match (strtolower(substr($raw, -1))) {
        'g' => $value * 1073741824,
        'm' => $value * 1048576,
        'k' => $value * 1024,
        default => $value,
    };
}

function cc_current_url_path(): string
{
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
    return is_string($path) ? $path : '/';
}

function cc_post_value(string $key, mixed $default = ''): mixed
{
    return $_POST[$key] ?? $default;
}

function cc_get_value(string $key, mixed $default = ''): mixed
{
    return $_GET[$key] ?? $default;
}

function cc_bool_from_post(string $key): bool
{
    return isset($_POST[$key]) && in_array((string) $_POST[$key], ['1', 'on', 'true', 'yes'], true);
}

function cc_slugify(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9_-]+/', '-', $value) ?? '';
    $value = trim($value, '-_');
    $value = preg_replace('/-+/', '-', $value) ?? '';
    return $value;
}

function cc_random_id(string $prefix): string
{
    return $prefix . '_' . gmdate('YmdHis') . '_' . bin2hex(random_bytes(5));
}

function cc_random_slug(int $length = 8): string
{
    $alphabet = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $slug = '';
    for ($i = 0; $i < $length; $i++) {
        $slug .= $alphabet[random_int(0, strlen($alphabet) - 1)];
    }
    return $slug;
}

function cc_client_ip(): string
{
    return (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}

function cc_private_hash(string $value): string
{
    $salt = hash('sha256', (string) cc_config('admin_password_hash') . cc_root_path());
    return hash('sha256', $salt . '|' . $value);
}

function cc_safe_filename(string $filename): string
{
    $filename = str_replace(["\0", "\r", "\n"], '', $filename);
    $filename = basename($filename);
    $filename = preg_replace('/[^\w.\- ()]+/', '_', $filename) ?? 'download';
    $filename = trim($filename, '. ');
    return $filename === '' ? 'download' : substr($filename, 0, 180);
}

function cc_bytes(int|float $bytes): string
{
    $units = ['B', 'KB', 'MB', 'GB'];
    $value = (float) $bytes;
    foreach ($units as $unit) {
        if ($value < 1024 || $unit === 'GB') {
            return rtrim(rtrim(number_format($value, 2), '0'), '.') . ' ' . $unit;
        }
        $value /= 1024;
    }
    return (string) $bytes . ' B';
}

function cc_flash(?string $message = null, string $type = 'success'): ?array
{
    if ($message !== null) {
        $_SESSION['flash'] = ['message' => $message, 'type' => $type];
        return null;
    }
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return is_array($flash) ? $flash : null;
}
