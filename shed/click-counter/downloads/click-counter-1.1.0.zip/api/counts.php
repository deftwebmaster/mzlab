<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/bootstrap.php';

cc_apply_counter_cors();
// One request can ask for up to 50 counters; each slug is looked up at most once.
$slugs = array_slice(array_unique(array_filter(array_map('cc_slugify', explode(',', (string) ($_GET['slugs'] ?? ''))))), 0, 50);
header('X-Content-Type-Options: nosniff');
$payload = ['success' => true, 'counts' => []];
foreach ($slugs as $slug) {
    $link = cc_find_link_by_slug($slug);
    if ($link && !empty($link['public_counter_enabled'])) {
        $payload['counts'][$slug] = (int) ($link['total_clicks'] ?? 0);
    }
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($payload, JSON_UNESCAPED_SLASHES);
