# Click Counter

Click Counter is a free, private, self-hosted click and download counter for ordinary websites, from [ManicZone Lab](https://lab.maniczone.com/click-counter/). It creates clean tracking URLs, counts valid clicks or download starts, shows basic daily statistics, and can expose a small public count for pages that need one.

It does not use SQL, Composer, npm, a PHP framework, third-party analytics, external APIs, or public user accounts.

## Features

- Single administrator login with secure PHP sessions, CSRF tokens, and login rate limiting.
- Redirect links for internal or external URLs.
- External download redirects for counting download starts.
- Protected local downloads streamed through PHP from private storage.
- Clean Apache routes such as `/go/summer-sale` and `/download/free-guide`.
- Query-string fallbacks: `redirect.php?slug=summer-sale` and `download.php?slug=free-guide`.
- Total counters, daily counters, recent activity, expiration, maximum-click limits, optional bot filtering, and optional temporary deduplication.
- Public count endpoints and a local JavaScript embed.
- CSV export with spreadsheet formula-injection protection.
- JSON backups, restore, diagnostics, and maintenance scripts.

## Requirements

- PHP 8.2 or newer
- Apache with `mod_rewrite` for clean URLs, or any PHP host using query-string fallback routes
- PHP JSON and sessions
- PHP Fileinfo recommended for protected file uploads
- Writable private storage directory

## Installation

1. Upload the `click-counter` folder to your website, for example `/click-counter/`.
2. Create a private storage folder outside the public web root when your host allows it, for example `/home/account/private/click-counter`.
3. Copy `config.example.php` to `config.php`.
4. Edit `config.php`:
   - Optionally set `base_url` to the folder's full address, for example `https://example.com/click-counter`. Left empty, it is detected from each request.
   - Set `timezone`.
   - Set `storage_path` and `files_path`.
   - Set `admin_password_hash`.
5. Make storage folders writable by PHP.
6. Open `/tools/generate-password.php`, generate a password hash, paste it into `config.php`, then delete the helper.
7. Open `/admin/` and create your first tracked link.
8. Open **Diagnostics** and confirm every check passes, including "Private storage blocked".

For a local smoke run with PHP installed:

```bash
php -S localhost:8000
```

Then open `http://localhost:8000/admin/`.

## Private Storage

Recommended private structure:

```text
click-counter-private/
├── data/
├── files/
├── backups/
├── logs/
├── locks/
└── temporary/
```

If storage must live inside the public project folder, Click Counter includes `.htaccess` deny files. Outside-web-root storage is still preferred.

## Creating Links

In the admin area, choose **Create** and enter a name, slug, link type, and destination.

`HEAD` requests and browser prefetches are answered but never counted, so link checkers and chat previews do not inflate totals or use up limited links.

Redirect links count the request and redirect to a stored URL. External download links count the request and redirect to a stored file URL. Protected local downloads count the request and stream a private file through PHP.

Slugs are normalized to lowercase letters, numbers, hyphens, and underscores. Reserved slugs such as `admin`, `go`, `download`, `api`, and `tools` are blocked.

## Clean URL Setup

Apache rules are included in `.htaccess`:

```apache
RewriteRule ^go/([A-Za-z0-9_-]+)/?$ redirect.php?slug=$1 [L,QSA]
RewriteRule ^download/([A-Za-z0-9_-]+)/?$ download.php?slug=$1 [L,QSA]
RewriteRule ^api/count/([A-Za-z0-9_-]+)/?$ api/count.php?slug=$1 [L,QSA]
```

Nginx example:

```nginx
location /click-counter/ {
    try_files $uri $uri/ /click-counter/index.php?$query_string;
}

rewrite ^/click-counter/go/([A-Za-z0-9_-]+)/?$ /click-counter/redirect.php?slug=$1 last;
rewrite ^/click-counter/download/([A-Za-z0-9_-]+)/?$ /click-counter/download.php?slug=$1 last;
rewrite ^/click-counter/api/count/([A-Za-z0-9_-]+)/json/?$ /click-counter/api/count.php?slug=$1&format=json last;
rewrite ^/click-counter/api/count/([A-Za-z0-9_-]+)/?$ /click-counter/api/count.php?slug=$1 last;

location ~ ^/click-counter/(includes|templates|tests|bin|private-storage)/ {
    deny all;
}

location ~ ^/click-counter/(config\.php|config\.example\.php|VERSION)$ {
    deny all;
}
```

Nginx ignores `.htaccess` files, so the `deny` rules above are what protect your data there. The Diagnostics page tests this for you.

## Public Counter Embed

Enable public counters for a link, then use:

```html
<span data-click-count="summer-sale" data-prefix="Downloaded " data-suffix=" times">-</span>
<script src="https://example.com/click-counter/assets/js/counter.js" defer></script>
```

Plain-text endpoint:

```text
/api/count/summer-sale
```

JSON endpoint:

```text
/api/count/summer-sale/json
```

The embed makes one request for every counter on the page and formats numbers for the visitor's locale (`1,234`); add `data-plain` to an element for the bare number. To show counts on a different domain, set `public_counter_cors` in `config.php`.

Without URL rewriting, use `api/count.php?slug=summer-sale` (add `&format=json` for JSON) or `api/counts.php?slugs=one,two` for several at once.

Public count endpoints expose only slug and count. They do not expose destinations, internal IDs, referrers, history, notes, visitor hashes, or private analytics.

## Privacy Behavior

By default, Click Counter stores aggregate counts and recent activity only. It does not store raw IP addresses, full user-agent strings, tracking cookies, external analytics, or browser fingerprints. Referrer storage keeps only the hostname. Device categories are approximate.

Temporary deduplication and estimated unique clicks use salted hashes and expiration windows. These are estimates, not identity systems.

## Backups and Restore

Use **Backups** in the admin area to create, download, and restore JSON backups. Backups are created before destructive actions such as deletion, reset, import, restore, and protected-file replacement.

Backups include JSON application data. They do not include protected file contents.

## CSV Export

Use **Exports** to download link reports as CSV. Values beginning with `=`, `+`, `-`, or `@` receive a leading apostrophe to reduce spreadsheet formula-injection risk.

## Maintenance

Run manually or by cron when desired:

```bash
php bin/maintenance.php
```

Maintenance trims recent activity, removes expired temporary visitor hashes and rate-limit records, prunes old backups, and reports missing protected files. The application still works without cron.

## Troubleshooting

- Admin login fails: verify `admin_password_hash` is set and regenerate the hash if needed. Repeated wrong passwords pause logins for `login_window_seconds`; successful logins never count.
- Pages load without styling, or links go to the wrong address: clear `base_url` in `config.php` (or set it to the folder's real address) and check Diagnostics.
- Clean URLs fail: confirm Apache rewrite support or use query-string fallbacks.
- Counts do not change: check storage and lock directories are writable.
- Protected downloads fail: confirm `files_path` points to a readable private directory and files were uploaded through the admin form.
- Public counter returns 404: enable the public counter for that link.
- Diagnostics warns about the password helper: delete `tools/generate-password.php` after setup.

## Scalability Limits

Click Counter is designed for personal sites, small businesses, blogs, landing pages, affiliate links, email campaigns, and modest download pages. Flat-file JSON storage is not intended for public URL-shortening services, millions of clicks, multi-server deployments, high-concurrency ad networks, or enterprise analytics.

## Upgrading

Back up your current installation, replace application files, keep your `config.php` and private storage, and run Diagnostics. Schema versioning is present in the data files for future migrations. See `CHANGELOG.md` for what changed in each release.

Upgrading from 1.0.0: no data changes are needed. Check any link that should expire — in 1.0.0, editing a link removed its expiration date, so re-enter dates that were lost. You may delete `IMPLEMENTATION_REPORT.md` and `tests/` from the server.

## Uninstallation

Remove the public Click Counter folder and the private storage folder. If you embedded public counters on other pages, remove the `<script>` tag and `data-click-count` elements.

## Tests

```bash
php tests/storage_smoke.php
php tests/concurrent_clicks.php
php tests/regressions.php
```

The tests run from the command line only and use a temporary directory, so they never touch your real data.

## Credits

Click Counter is made and maintained by ManicZone Lab as part of the Script Shed: https://lab.maniczone.com/shed/

## License

MIT. Copyright (c) 2026 ManicZone Lab.
